-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 年 12 月 13 日 17:43
-- 服务器版本: 5.7.22
-- PHP 版本: 5.3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `mobanw.cn`
--

-- --------------------------------------------------------

--
-- 表的结构 `clt_ad`
--

CREATE TABLE IF NOT EXISTS `clt_ad` (
  `ad_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '广告名称',
  `type_id` tinyint(5) NOT NULL COMMENT '所属位置',
  `pic` varchar(200) NOT NULL DEFAULT '' COMMENT '广告图片URL',
  `url` varchar(200) NOT NULL DEFAULT '' COMMENT '广告链接',
  `addtime` int(11) NOT NULL COMMENT '添加时间',
  `sort` int(11) NOT NULL COMMENT '排序',
  `open` tinyint(2) NOT NULL COMMENT '1=审核  0=未审核',
  `content` varchar(225) DEFAULT '' COMMENT '广告内容',
  PRIMARY KEY (`ad_id`),
  KEY `plug_ad_adtypeid` (`type_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='广告表' AUTO_INCREMENT=36 ;

--
-- 转存表中的数据 `clt_ad`
--

INSERT INTO `clt_ad` (`ad_id`, `name`, `type_id`, `pic`, `url`, `addtime`, `sort`, `open`, `content`) VALUES
(15, 'CLTPHP的目的是 让所有人都能 高效 简洁 的建立网站', 1, '/uploads/20180611/c09ce57b7b5264ccbefef44c2591117b.png', 'http://demo.cltphp.com', 1480909037, 1, 0, '虽然世界上有成千上万的建站系统，但CLTPHP会告诉你，真正高效的建站系统是什么样的。'),
(17, '即使是后台我们也极力追求尽善尽美', 1, '/uploads/20180611/25e5f5a08933130f026a6119666b44a8.png', 'http://demo.cltphp.com', 1481788850, 2, 1, 'CLTPHP采用了优美的layui框架，一面极简，一面丰盈。加上angular Js，让数据交互变得更为简洁直白。用最基础的代码，实现最强大的效果，让你欲罢不能！'),
(18, 'ThinkPHP5极大的提高了CLTPHP的可拓展性', 1, '/uploads/20180611/814e5f76ef5dce49dfd3dce771631ecf.png', 'http://demo.cltphp.com', 1481788869, 3, 1, 'CLTPHP采用的ThinkPHP5为基础框架，从而使得CLTPHP的拓展性变的极为强大。从模型构造到栏目建立，再到前台展示，一气呵成，网站后台一条龙式操作，让小白用户能快速掌握CLTPHP管理系统的核心操作，让小白开发者能更好的理解CLTPHP的核心构建价值。');

-- --------------------------------------------------------

--
-- 表的结构 `clt_admin`
--

CREATE TABLE IF NOT EXISTS `clt_admin` (
  `admin_id` tinyint(4) NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `username` varchar(20) NOT NULL COMMENT '管理员用户名',
  `pwd` varchar(70) NOT NULL COMMENT '管理员密码',
  `group_id` mediumint(8) DEFAULT NULL COMMENT '分组ID',
  `email` varchar(30) DEFAULT NULL COMMENT '邮箱',
  `realname` varchar(10) DEFAULT NULL COMMENT '真实姓名',
  `tel` varchar(30) DEFAULT NULL COMMENT '电话号码',
  `ip` varchar(20) DEFAULT NULL COMMENT 'IP地址',
  `add_time` int(11) DEFAULT NULL COMMENT '添加时间',
  `mdemail` varchar(50) DEFAULT '0' COMMENT '传递修改密码参数加密',
  `is_open` tinyint(2) DEFAULT '0' COMMENT '审核状态',
  `avatar` varchar(120) DEFAULT '' COMMENT '头像',
  PRIMARY KEY (`admin_id`),
  KEY `admin_username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='后台管理员' AUTO_INCREMENT=12 ;

--
-- 转存表中的数据 `clt_admin`
--

INSERT INTO `clt_admin` (`admin_id`, `username`, `pwd`, `group_id`, `email`, `realname`, `tel`, `ip`, `add_time`, `mdemail`, `is_open`, `avatar`) VALUES
(1, 'admin', '0192023a7bbd73250516f069df18b500', 1, '1158624818@qq.com', '', '13122707159', '127.0.0.1', 1482132862, '0', 1, '/uploads/20180625/f266169c2956429d9aaea6cf6f1e51cb.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `clt_ad_type`
--

CREATE TABLE IF NOT EXISTS `clt_ad_type` (
  `type_id` tinyint(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '广告位名称',
  `sort` int(11) NOT NULL COMMENT '广告位排序',
  PRIMARY KEY (`type_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='广告分类' AUTO_INCREMENT=10 ;

--
-- 转存表中的数据 `clt_ad_type`
--

INSERT INTO `clt_ad_type` (`type_id`, `name`, `sort`) VALUES
(1, '【首页】顶部轮播', 1),
(5, '【内页】横幅', 2);

-- --------------------------------------------------------

--
-- 表的结构 `clt_article`
--

CREATE TABLE IF NOT EXISTS `clt_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `title` varchar(80) NOT NULL DEFAULT '',
  `keywords` varchar(120) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `content` text NOT NULL COMMENT '内容',
  `template` varchar(40) NOT NULL DEFAULT '',
  `posid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `status` varchar(255) NOT NULL DEFAULT '1',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `readgroup` varchar(100) NOT NULL DEFAULT '',
  `readpoint` smallint(5) NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `copyfrom` varchar(255) NOT NULL DEFAULT 'CLTPHP',
  `fromlink` varchar(255) NOT NULL DEFAULT 'http://www.cltphp.com/',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `title_style` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`sort`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `listorder` (`id`,`catid`,`status`,`sort`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=53 ;

--
-- 转存表中的数据 `clt_article`
--

INSERT INTO `clt_article` (`id`, `catid`, `userid`, `username`, `title`, `keywords`, `description`, `content`, `template`, `posid`, `status`, `recommend`, `readgroup`, `readpoint`, `sort`, `hits`, `createtime`, `updatetime`, `copyfrom`, `fromlink`, `thumb`, `title_style`) VALUES
(51, 4, 1, 'admin', '下拉菜单设计指南', '网页设计, 设计原则, 网页设计, 设计原则', '下拉菜单在网页设计中显然占有一席之地。然而，他们的过度使用和误用造成了许多可用性问题和混乱。设计师们为了各种不同的目的而使用下拉', '<h3 style="margin: 5px 0px 20px; font-family: "><span style="color: rgb(255, 102, 0);"><strong>下拉菜单的使用</strong></span></h3><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">下拉菜单在网页设计中显然占有一席之地。然而，他们的过度使用和误用造成了许多可用性问题和混乱。设计师们为了各种不同的目的而使用下拉，包括:</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><h3 style="margin: 5px 0px 20px; font-family: "><span style="color: rgb(0, 0, 0);"><strong>命令菜单，它根据所选选项启动一个操作</strong></span></h3><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><img class="alignnone size-full wp-image-144813" src="/uploads/ueditor/image/20181213/1544666980114950.png" alt="Image title" width="900"/></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><span style="color: rgb(153, 153, 153);">当用户单击“发布” 图标时，Microsoft Word使用下拉菜单显示发布命令</span></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><h3 style="margin: 5px 0px 20px; font-family: "><strong>导航菜单，它将用户带到一个新的位置</strong></h3><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><img class="alignnone size-full wp-image-144814" src="/uploads/ueditor/image/20181213/1544666980433717.png" alt="Image title" width="900"/></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><span style="color: rgb(153, 153, 153);">阿里云使用下拉菜单为每个顶级类别提供子类别链接列表</span></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><h3 style="margin: 5px 0px 20px; font-family: "><strong>表单填充，让用户选择一个选项进入表单字段</strong></h3><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><img class="alignnone size-full wp-image-144815" src="/uploads/ueditor/image/20181213/1544666980240547.png" alt="Image title" width="900"/></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><span style="color: rgb(153, 153, 153);">Element下拉组件</span></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><h3 style="margin: 5px 0px 20px; font-family: "><strong>属性选择，允许用户从可能值的菜单中选择一个值</strong></h3><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><img class="alignnone size-full wp-image-144818" src="/uploads/ueditor/image/20181213/1544666980107678.png" alt="Image title" width="900"/></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><span style="color: rgb(153, 153, 153);">Adobe Color CC允许用户从颜色规则列表中选择调色板</span></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">虽然最初的术语“下拉框”和“下拉菜单”可以互换使用，但随着时间的推移，两者之间出现了功能上的区别。现在，下拉菜单主要包括下拉菜单的前两种用法(导航和命令列表)，而下拉框通常是表单填充和属性选择的选择方法。</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">下拉框通常与下拉菜单不同:它们旁边有一个下拉箭头，用于选择属性或输入表单数据。这个控件倾向于一个字段标签或一个标题，这个标题在下拉框中占据第一项的位置，以便在进行选择之前可以看到它。尽管MacOS和Windows有不同的下拉式实现，但在这两种情况下，命令菜单都不同于属性选择菜单。事实上，Macintosh人机界面指导原则明确建议不要使用下拉菜单来执行命令。</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><h3 style="margin: 5px 0px 20px; font-family: "><span style="color: rgb(255, 102, 0);"><strong>下拉式设计指南</strong></span></h3><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">下拉菜单确实有其优点。首先，它们节省了屏幕空间。因为它们是一个标准的小部件（即使是不愉快的小部件），用户也知道如何处理它们。而且，当使用表单和属性选择时，下拉框会阻止用户输入错误的数据，因为它们只显示合法的选择。</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">尽管有这些优点，但如果设计者较少使用下拉菜单，web可用性就会增加。为此，以下是一些关于下拉的设计准则:</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><span style="color: rgb(0, 0, 0);"><strong>1、避免交互式菜单，</strong></span>其中当用户在同一页面的另一菜单中选择某些内容时，菜单中的选项会改变。当选择来来去去的时候，用户会感到非常困惑，当它依赖于一个不同的小部件中的选择时，通常很难看到想要的选项。</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><img class="alignnone size-full wp-image-144819" src="/uploads/ueditor/image/20181213/1544666981106288.png" alt="Image title" width="900"/></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><span style="color: rgb(153, 153, 153);">iTunes：视图菜单包含不同的选项，具体取决于在库侧面菜单中是选择了相册（左）还是歌曲（右）</span></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><strong>2、灰掉任何不可用的选项而不是删除它们：</strong>任何无法选择的项目都应保留在视图中。对于额外的用户体验，如果用户在一个灰色的选项上停留超过一秒，可以考虑显示一个简短的气球帮助信息，解释为什么这个选项是禁用的，以及如何使它激活。</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">如果删除了禁用的项，界面就失去了空间一致性，变得更难学习。</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><img class="size-full wp-image-144817 aligncenter" title="Image title" src="/uploads/ueditor/image/20181213/1544666981867176.png" alt="Image title" width="420"/></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><span style="color: rgb(153, 153, 153);">Snagit：“渐变” 和“容差” 选项呈灰色显示，表示在选择“无填充” 选项时无法选择它们</span></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><strong>3、需要滚动的非常长的下拉菜单使得用户无法一眼看到他们的所有选择。</strong>也需要小心的转向鼠标，这样它就不会离开下拉。（这是转向定律的一个例子，它指出用户通过隧道引导一个指向设备的时间取决于隧道的长度和宽度:隧道越长越窄，占用的时间就越多用户将指针从一端移动到另一端，转向定律来源于Fitts定律）</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">在可能的情况下，抵制住诱惑。如果你有很多项目，可以考虑其他的方式来展示它们——比如传统链接的HTML列表或者超级菜单，它们是二维的而不是线性的，并且提供更简单的鼠标管理，并且更快的平均时间到达里面的项目。</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><img class="alignnone size-full wp-image-144820" title="Image title" src="/uploads/ueditor/image/20181213/1544666981111753.png" alt="Image title" width="900"/></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><span style="color: rgb(153, 153, 153);">百度的模糊匹配</span></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><strong>4、在打字时要避免下拉框。</strong>典型的情况包括国家或国家的名单，例如邮寄地址。比起从滚动下拉菜单中选择一个状态，用户简单地输入“NY”要快得多。对带有受限选项的字段进行自由格式输入确实需要在后端进行数据验证，但从可用性的角度来看，这往往是最好的方法。（这是我们的电子商务可用性准则之一，因为我们在签入表单时使用状态下拉列表观察到了许多错误。）</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><img class="alignnone size-full wp-image-144816" title="Image title" src="/uploads/ueditor/image/20181213/1544666981112506.png" alt="Image title" width="900"/></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><span style="color: rgb(153, 153, 153);">Ant Design 在查找控件时输入关键字会比下拉选择快得多</span></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><strong>5、避免使用下拉框，以获取对用户非常熟悉的数据。</strong>比如他们的出生日期、月份或年份。这些信息通常都是硬连接到用户的手指上的，而且要在长菜单中找到这些选项是很繁琐的，打破了之前的指导方针，并且给用户创造了更多的工作。</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><img class="alignnone size-full wp-image-144822" title="Image title" src="/uploads/ueditor/image/20181213/1544666981319769.png" alt="Image title" width="900"/></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><span style="color: rgb(153, 153, 153);">输入年月日会更容易</span></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><strong>6、当下拉菜单打开时，保持菜单标签或描述。</strong>菜单标题通过提醒用户他们选择的内容来提供范围和方向。在打开菜单时，当标签被隐藏或删除时，用户必须回忆他们在采取行动之前需要选择的内容。计划中断，随时可能中断用户的任务。</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><img class="alignnone size-full wp-image-144821" title="Image title" src="/uploads/ueditor/image/20181213/1544666982870231.png" alt="Image title" width="900"/></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><span style="color: rgb(153, 153, 153);">在下拉菜单打开时，隐藏了标签 用户需要重新调用该标签才能了解下拉列表中选项的上下文</span></p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><strong>7、在桌面的下拉菜单中保留全局导航选项。</strong>隐藏你的网站的顶级类别可能对用户在任何网站上的成功是有害的。</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: "><strong>8、支持键盘输入以在下拉菜单内进行导航。</strong>下拉菜单（菜单和框）应该不仅支持鼠标输入，而且支持按键。在下拉菜单中，访问键应使用户能够在不使用鼠标的情况下快速选择可见选项。在下拉框中，用户应该能够键入一个字母并快速导航到以该字母开头的选项。</p><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">&nbsp;</p><h3 style="margin: 5px 0px 20px; font-family: "><span style="color: rgb(255, 102, 0);"><strong>总结</strong></span></h3><p style="margin-top: 0px; margin-bottom: 15px; color: rgb(85, 85, 85); font-family: ">下拉框和菜单被过度使用会显得笨拙，但是可以用于显示选项或命令列表。</p><p><br/></p>', '0', 0, '1', 0, '', 0, 0, 13, 1544666977, 1544667310, 'CLTPHP', 'http://mobanw.cn/', '/uploads/20181213/6f8ab94a7950041c17a13af57a838b53.png', 'color:;font-weight:normal;'),
(52, 5, 1, 'admin', 'mysql 数据库引擎', '数据库引擎，MySQL数据库引擎类别，Innodb引擎', '数据库引擎是用于存储、处理和保护数据的核心服务。利用数据库引擎可控制访问权限并快速处理事务，从而满足企业内大多数需要处理大量数据的应用程序的要求。 使用数据库引擎创建用于联机事务处理或联机分析处理数据的关系数据库', '<p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(0, 152, 221); color: white; font-size: 17px; font-weight: bold;">一、数据库引擎</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　<strong>数据库引擎</strong>是用于<span style="color: rgb(255, 0, 0);">存储、处理和保护数据的核心服务</span>。利用数据库引擎可控制访问权限并快速处理事务，从而满足企业内大多数需要处理大量数据的应用程序的要求。 使用数据库引擎创建用于联机事务处理或联机分析处理数据的关系数据库。这包括创建用于存储数据的表和用于查看、管理和保护数据安全的数据库对象（如索引、视图和存储过程）。</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(0, 152, 221); color: white; font-size: 17px; font-weight: bold;">二、数据库引擎任务</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　在数据库引擎文档中，<span style="color: rgb(255, 0, 0);">各主题的<strong>顺序</strong></span>遵循用于实现使用数据库引擎进行数据存储的系统的任务的主要顺序。</p><ul style="margin-left: 30px; padding-left: 0px; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);" class=" list-paddingleft-2"><li><p>设计并创建数据库以保存系统所需的关系或XML文档</p></li><li><p>实现系统以访问和更改数据库中存储的数据。包括实现网站或使用数据的应用程序，还包括生成使用SQL Server工具和实用工具以使用数据的过程。</p></li><li><p>为单位或客户部署实现的系统</p></li><li><p>提供日常管理支持以优化数据库的性能</p></li></ul><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(0, 152, 221); color: white; font-size: 17px; font-weight: bold;">三、MySQL数据库引擎类别</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　你能用的数据库引擎取决于mysql在安装的时候是如何被编译的。要添加一个新的引擎，就必须重新编译MYSQL。在<span style="color: rgb(255, 0, 0);">缺省情况下</span>，MYSQL支持三个引擎：<strong>ISAM、MYISAM和HEAP</strong>。另外两种类型<strong>INNODB</strong>和<strong>BERKLEY</strong>（BDB），也常常可以使用。</p><h3 class="title-text" style="font-size: 18px; border-bottom: 1px solid rgb(170, 170, 170); line-height: 1.5; margin: 10px; padding-left: 10px;">ISAM</h3><p>　　ISAM是一个定义明确且历经时间考验的数据表格管理方法，它在设计之时就考虑到数据库被查询的次数要远大于更新的次数。因此，ISAM执行读取操作的速度很快，而且不占用大量的内存和存储资源。ISAM的两个主要<strong>不足之处</strong>在于，它<strong>不支持事务处理</strong>，也<strong>不能够容错</strong>：如果你的硬盘崩溃了，那么数据文件就无法恢复了。如果你正在把ISAM用在关键任务应用程序里，那就必须经常备份你所有的实时数据，通过其复制特性，MYSQL能够支持这样的备份应用程序。</p><h3 class="title-text" style="font-size: 18px; border-bottom: 1px solid rgb(170, 170, 170); line-height: 1.5; margin: 10px; padding-left: 10px;">MYISAM</h3><p>　　MYISAM是MYSQL的ISAM扩展格式和<strong><span style="color: rgb(255, 0, 0);">缺省</span>的数据库引擎</strong>。除了<strong>提供</strong>ISAM里所没有的<strong>索引和字段管理的</strong>功能，MYISAM还使用一种<strong>表格锁定的机制</strong>，来<strong>优化多个并发的读写操作</strong>。其代价是你需要经常运行OPTIMIZE TABLE命令，来恢复被更新机制所浪费的空间。MYISAM还有一些有用的扩展，例如用来修复数据库文件的MYISAMCHK工具和用来恢复浪费空间的MYISAMPACK工具。</p><p>　　MYISAM强调了快速读取操作，这可能就是为什么MYSQL受到了WEB开发如此青睐的主要原因：在WEB开发中你所进行的大量数据操作都是读取操作。所以，大多数虚拟主机提供商和INTERNET平台提供商只允许使用MYISAM格式。</p><h3 class="title-text" style="font-size: 18px; border-bottom: 1px solid rgb(170, 170, 170); line-height: 1.5; margin: 10px; padding-left: 10px;">HEAP</h3><p>　　HEAP<strong>允许只驻留在内存里的临时表格</strong>。驻留在内存里让HEAP要比ISAM和MYISAM都快，但是它所<strong>管理的数据是不稳定的</strong>，而且如果在关机之前没有进行保存，那么所有的数据都会丢失。在数据行被删除的时候，HEAP也不会浪费大量的空间。HEAP表格在你需要使用SELECT表达式来选择和操控数据的时候非常有用。要记住，在用完表格之后就删除表格。</p><h3 class="title-text" style="font-size: 18px; border-bottom: 1px solid rgb(170, 170, 170); line-height: 1.5; margin: 10px; padding-left: 10px;">INNODB和BERKLEYDB</h3><p>　　INNODB和BERKLEYDB（BDB）数据库引擎都是造就MYSQL灵活性的技术的直接产品，这项技术就是MYSQL++ API。在使用MYSQL的时候，你所面对的每一个挑战几乎都源于ISAM和MYISAM数据库引擎不支持事务处理也不支持外来键。尽管要比ISAM和MYISAM引擎慢很多，但是INNODB和BDB包括了<span style="color: rgb(255, 0, 0);"><strong>对事务处理和外来键的支持</strong></span>，这两点都是前两个引擎所没有的。如前所述，如果你的设计需要这些特性中的一者或者两者，那你就要被迫使用后两个引擎中的一个了。</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(0, 152, 221); color: white; font-size: 17px; font-weight: bold;">四、mysql数据引擎更换方式</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);"><span style="font-size: 16px;"><strong>1、查看当前数据库支持的引擎和默认的数据库引擎：</strong></span></p><pre style="margin-top: 0px; margin-bottom: 0px; margin-left: 22px; white-space: pre-wrap; overflow-wrap: break-word; font-family: &quot;Courier New&quot; !important;">show&nbsp;engines;</pre><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　我的查询结果如下：</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);"><img src="/uploads/ueditor/image/20181213/1544668998128484.png" alt=""/></p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);"><strong><span style="font-size: 16px;">2、更改数据库引擎</span></strong></p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">2.1、更改方式1：修改配置文件my.ini</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　将my-small.ini另存为my.ini，在[mysqld]后面添加default-storage-engine=InnoDB，重启服务，数据库默认的引擎修改为InnoDB</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">2.2、更改方式2:在建表的时候指定</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">&nbsp; &nbsp; &nbsp;建表时指定：</p><pre style="margin-top: 0px; margin-bottom: 0px; margin-left: 22px; white-space: pre-wrap; overflow-wrap: break-word; font-family: &quot;Courier New&quot; !important;">create&nbsp;table&nbsp;mytbl(&nbsp;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;id&nbsp;int&nbsp;primary&nbsp;key,&nbsp;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;name&nbsp;varchar(50)&nbsp;&nbsp;&nbsp;\n)type=MyISAM;</pre><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">2.3、更改方式3：建表后更改</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　alter table mytbl2 type = InnoDB;</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);"><strong><span style="font-size: 16px;">3、查看修改结果</span></strong></p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　方式1：</p><pre style="margin-top: 0px; margin-bottom: 0px; margin-left: 22px; white-space: pre-wrap; overflow-wrap: break-word; font-family: &quot;Courier New&quot; !important;">show&nbsp;table&nbsp;status&nbsp;from&nbsp;mytest;</pre><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　方式2：</p><pre style="margin-top: 0px; margin-bottom: 0px; margin-left: 22px; white-space: pre-wrap; overflow-wrap: break-word; font-family: &quot;Courier New&quot; !important;">show&nbsp;create&nbsp;table&nbsp;table_name</pre><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(0, 152, 221); color: white; font-size: 17px; font-weight: bold;">五、MyIASM 和 Innodb引擎详解</p><h2 style="margin: 10px 0px; font-size: 20px; line-height: 1.5; font-family: Verdana, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);">Innodb引擎</h2><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　Innodb引擎提供了对数据库<span style="color: rgb(255, 0, 0);">ACID<strong>事务</strong></span>的支持，并且实现了SQL标准的四种隔离级别，关于数据库事务与其隔离级别的内容请见数据库事务与其隔离级别这篇文章。该引擎还提供了行级锁和外键约束，它的设计目标是处理大容量数据库系统，它本身其实就是基于MySQL后台的完整数据库系统，MySQL运行时Innodb会在内存中建立缓冲池，用于缓冲数据和索引。但是该引擎不支持FULLTEXT类型的索引，而且它没有保存表的行数，当<span style="color: rgb(255, 0, 0);">SELECT COUNT(*) FROM TABLE时需要扫描全表</span>。当需要使用数据库事务时，该引擎当然是首选。由于锁的粒度更小，写操作不会锁定全表，所以在并发较高时，使用Innodb引擎会提升效率。但是使用行级锁也不是绝对的，如果在执行一个SQL语句时MySQL不能确定要扫描的范围，InnoDB表同样会锁全表。</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">名词解析：</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);"><span style="font-size: 15px;"><strong>ACID</strong></span></p><ul style="margin-left: 30px; padding-left: 0px; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);" class=" list-paddingleft-2"><li><p><strong>A</strong>&nbsp;&nbsp;事务的<strong>原子性</strong>(Atomicity)：<strong>指一个事务要么全部执行,要么不执行</strong>.也就是说一个事务不可能只执行了一半就停止了.比如你从取款机取钱,这个事务可以分成两个步骤:1划卡,2出钱.不可能划了卡,而钱却没出来.这两步必须同时完成.要么就不完成.</p></li><li><p><strong>C</strong>&nbsp;事务的<strong>一致性</strong>(Consistency)：指事务的运行并不改变数据库中数据的一致性.例如,完整性约束了a+b=10,一个事务改变了a,那么b也应该随之改变.</p></li><li><p><strong>I</strong>&nbsp;<strong>独立性</strong>(Isolation）:事务的独立性也有称作隔离性,是指两个以上的事务不会出现交错执行的状态.因为这样可能会导致数据不一致.</p></li><li><p><strong>D</strong>&nbsp;<strong>持久性</strong>(Durability）:事务的持久性是指事务执行成功以后,该事务所对数据库所作的更改便是持久的保存在数据库之中，不会无缘无故的回滚.</p></li></ul><h2 style="margin: 10px 0px; font-size: 20px; line-height: 1.5; font-family: Verdana, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);">MyIASM引擎</h2><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　MyIASM是MySQL默认的引擎，但是它<span style="color: rgb(255, 0, 0);">没有提供对数据库事务的支持，也不支持行级锁和外键</span>，因此<span style="color: rgb(255, 0, 0);">当INSERT(插入)或UPDATE(更新)数据时即写操作需要锁定整个表，效率便会低一些</span>。不过和Innodb不同，MyIASM中<span style="color: rgb(255, 0, 0);">存储了表的行数</span>，于是<span style="color: rgb(255, 0, 0);">SELECT COUNT(*) FROM TABLE时只需要直接读取已经保存好的值</span>而不需要进行全表扫描。如果表的读操作远远多于写操作且不需要数据库事务的支持，那么MyIASM也是很好的选择。</p><h2 style="margin: 10px 0px; font-size: 20px; line-height: 1.5; font-family: Verdana, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);">两种引擎的选择</h2><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　大尺寸的数据集趋向于选择InnoDB引擎，因为它支持事务处理和故障恢复。数据库的大小决定了故障恢复的时间长短，InnoDB可以利用事务日志进行数据恢复，这会比较快。主键查询在InnoDB引擎下也会相当快，不过需要注意的是如果主键太长也会导致性能问题，关于这个问题我会在下文中讲到。大批的INSERT语句(在每个INSERT语句中写入多行，批量插入)在MyISAM下会快一些，但是UPDATE语句在InnoDB下则会更快一些，尤其是在并发量大的时候。</p><h2 style="margin: 10px 0px; font-size: 20px; line-height: 1.5; font-family: Verdana, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);">Index——索引</h2><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　<strong>索引</strong>（Index）是<strong>帮助MySQL高效获取数据的<span style="color: rgb(255, 0, 0);">数据结构</span></strong>。MyIASM和Innodb都使用了树这种数据结构做为索引。下面我接着讲这两种引擎使用的索引结构，讲到这里，首先应该谈一下B-Tree和B+Tree。</p><h3 style="font-size: 18px; border-bottom: 1px solid rgb(170, 170, 170); line-height: 1.5; margin: 10px; padding-left: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);">MyIASM引擎的索引结构</h3><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　MyISAM引擎的索引结构为<strong>B+Tree</strong>，其中<span style="color: rgb(255, 0, 0);">B+Tree的</span><strong><span style="color: rgb(255, 0, 0);">数据域存储</span>的内容为<span style="color: rgb(255, 0, 0);">实际数据的地址</span></strong>，也就是说它的索引和实际的数据是分开的，只不过是用索引指向了实际的数据，这种索引就是所谓的<strong>非聚集索引</strong>。如下图所示：</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);"><img src="/uploads/ueditor/image/20181213/1544668999314519.png" alt="" width="538" height="389"/></p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　这里设表一共有三列，假设我们以Col1为主键，则上图是一个MyISAM表的主索引（Primary key）示意。可以看出MyISAM的索引文件仅仅保存数据记录的地址。在MyISAM中，主索引和辅助索引（Secondary key）在结构上没有任何区别，只是主索引要求key是唯一的，而辅助索引的key可以重复。如果我们<span style="color: rgb(255, 0, 0);">在Col2上建立一个辅助索引</span>，则此索引的结构如下图所示：</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);"><img src="/uploads/ueditor/image/20181213/1544668999970667.png" alt=""/></p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　同样也是一颗B+Tree，data域保存数据记录的地址。因此，MyISAM中索引检索的算法为首先按照B+Tree搜索算法搜索索引，如果指定的Key存在，则取出其data域的值，然后以data域的值为地址，读取相应数据记录。</p><h3 style="font-size: 18px; border-bottom: 1px solid rgb(170, 170, 170); line-height: 1.5; margin: 10px; padding-left: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);">Innodb引擎的索引结构</h3><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　与MyISAM引擎的索引结构同样也是B+Tree，但是Innodb的<span style="color: rgb(255, 0, 0);">索引文件本身就是数据文件，</span>即<strong><span style="color: rgb(255, 0, 0);">B+Tree的数据域存储的就是实际的数据</span></strong>，这种索引就是<strong>聚集索引</strong>。这个<span style="color: rgb(255, 0, 0);">索引的key就是数据表的主键</span>，因此InnoDB表数据文件本身就是主索引。</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　并且和MyISAM不同，<span style="color: rgb(255, 0, 0);">InnoDB的<strong><span style="font-size: 16px;"><span style="font-size: 18px;">辅助</span>索引数据域</span>存储的也是相应记录主键的值</strong>而不是地址，所以当以辅助索引查找时，会先根据辅助索引找到主键，再根据主键索引找到实际的数据</span>。所以Innodb不建议使用过长的主键，否则会使辅助索引变得过大。建议使用自增的字段作为主键，这样B+Tree的每一个结点都会被顺序的填满，而不会频繁的分裂调整，会有效的提升插入数据的效率。</p><p>两者区别：<br/></p><p>　　第一个重大区别是InnoDB的数据文件本身就是索引文件。从上文知道，MyISAM索引文件和数据文件是分离的，索引文件仅保存数据记录的地址。而在InnoDB中，表数据文件本身就是按B+Tree组织的一个索引结构，这棵树的叶节点data域保存了完整的数据记录。这个索引的key是数据表的主键，因此InnoDB表数据文件本身就是主索引。</p><p><img src="/uploads/ueditor/image/20181213/1544668999343350.jpg" alt=""/></p><p>　　上图是InnoDB主索引（同时也是数据文件）的示意图，可以看到叶节点包含了完整的数据记录。这种索引叫做聚集索引。因为InnoDB的数据文件本身要按主键聚集，所以<span style="color: rgb(255, 0, 0);">InnoDB要求表必须有主键</span>（MyISAM可以没有），如果没有显式指定，则MySQL系统会自动选择一个可以唯一标识数据记录的列作为主键，如果不存在这种列，则MySQL自动为InnoDB表生成一个隐含字段作为主键，这个字段长度为6个字节，类型为长整形。</p><p>&nbsp;</p><p>&nbsp;</p><p>　　第二个与MyISAM索引的不同是InnoDB的辅助索引data域存储相应记录主键的值而不是地址。换句话说，InnoDB的所有辅助索引都引用主键作为data域。例如，下图为定义在Col3上的一个辅助索引：</p><p><img src="/uploads/ueditor/image/20181213/1544668999729431.jpg" alt=""/></p><p>　　这里以英文字符的ASCII码作为比较准则。聚集索引这种实现方式使得按主键的搜索十分高效，但是辅助索引搜索需要检索两遍索引：首先检索辅助索引获得主键，然后用主键到主索引中检索获得记录。<br/>&nbsp;</p><p>　　了解不同存储引擎的索引实现方式对于正确使用和优化索引都非常有帮助，例如知道了InnoDB的索引实现后，就很容易明白为什么不建议使用过长的字段作为主键，因为所有辅助索引都引用主索引，过长的主索引会令辅助索引变得过大。再例如，用非单调(可能是指“非递增”的意思)的字段作为主键在InnoDB中不是个好主意，因为InnoDB数据文件本身是一颗B+Tree，非单调(可能是指“非递增”的意思)的主键会造成在插入新记录时数据文件为了维持B+Tree的特性而频繁的分裂调整，十分低效，而使用自增字段作为主键则是一个很好的选择。</p><p style="margin: 10px auto; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; white-space: normal; background-color: rgb(255, 255, 255);">　　<strong>致谢</strong>：感谢您的阅读！</p><p><br/></p>', '0', 0, '1', 0, '', 0, 0, 5, 1544668808, 0, 'CLTPHP', 'http://www.cltphp.com/', '/uploads/20181213/f10ec4e72122b0a306253a155a52debb.png', 'color:;font-weight:normal;');

-- --------------------------------------------------------

--
-- 表的结构 `clt_auth_group`
--

CREATE TABLE IF NOT EXISTS `clt_auth_group` (
  `group_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '全新ID',
  `title` char(100) NOT NULL DEFAULT '' COMMENT '标题',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态',
  `rules` longtext COMMENT '规则',
  `addtime` int(11) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='管理员分组' AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `clt_auth_group`
--

INSERT INTO `clt_auth_group` (`group_id`, `title`, `status`, `rules`, `addtime`) VALUES
(1, '超级管理员', 1, '0,1,2,270,15,16,119,120,121,145,17,149,116,117,118,151,181,18,108,114,112,109,110,111,3,5,126,127,128,4,230,232,129,189,190,193,192,240,239,241,243,244,245,242,246,7,9,14,234,13,235,236,237,238,27,29,161,163,164,162,38,167,182,169,166,28,48,247,248,31,32,249,250,251,45,170,171,175,174,173,46,176,183,179,178,265,196,197,202,198,252,253,254,255,256,203,205,204,257,272,206,207,212,208,213,258,259,260,261,262,209,215,214,263,273,267,269,', 1465114224),
(2, '管理员', 1, '0,1,2,270,15,16,145,17,181,18,111,3,5,127,128,4,129,189,190,239,241,242,7,9,14,13,27,29,161,163,164,162,38,167,182,169,166,28,48,31,32,45,174,46,179,196,197,202,252,203,204,272,206,207,212,208,260,209,215,267,269,', 1465114224),
(3, '商品管理员', 1, '27,29,161,163,164,162,38,167,182,169,166,', 1465114224);

-- --------------------------------------------------------

--
-- 表的结构 `clt_auth_rule`
--

CREATE TABLE IF NOT EXISTS `clt_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `href` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `authopen` tinyint(2) NOT NULL DEFAULT '1',
  `icon` varchar(20) DEFAULT NULL COMMENT '样式',
  `condition` char(100) DEFAULT '',
  `pid` int(5) NOT NULL DEFAULT '0' COMMENT '父栏目ID',
  `sort` int(11) DEFAULT '0' COMMENT '排序',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `zt` int(1) DEFAULT NULL,
  `menustatus` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='权限节点' AUTO_INCREMENT=286 ;

--
-- 转存表中的数据 `clt_auth_rule`
--

INSERT INTO `clt_auth_rule` (`id`, `href`, `title`, `type`, `status`, `authopen`, `icon`, `condition`, `pid`, `sort`, `addtime`, `zt`, `menustatus`) VALUES
(1, 'System', '系统设置', 1, 1, 0, 'icon-cogs', '', 0, 0, 1446535750, 1, 1),
(2, 'System/system', '系统设置', 1, 1, 0, '', '', 1, 1, 1446535789, 1, 1),
(3, 'Database/database', '数据库管理', 1, 1, 0, 'icon-database', '', 0, 11, 1446535805, 1, 1),
(4, 'Database/restore', '还原数据库', 1, 1, 0, '', '', 3, 10, 1446535750, 1, 1),
(5, 'Database/database', '数据库备份', 1, 1, 0, '', '', 3, 1, 1446535834, 1, 1),
(7, 'Category', '栏目管理', 1, 1, 0, 'icon-list', '', 0, 2, 1446535875, 1, 1),
(9, 'Category/index', '栏目列表', 1, 1, 0, '', '', 7, 0, 1446535750, 1, 1),
(13, 'Category/edit', '操作-修改', 1, 1, 0, '', '', 9, 3, 1446535750, 1, 0),
(14, 'Category/add', '操作-添加', 1, 1, 0, '', '', 9, 0, 1446535750, 1, 0),
(15, 'Auth/adminList', '权限管理', 1, 1, 0, 'icon-lifebuoy', '', 0, 1, 1446535750, 1, 1),
(16, 'Auth/adminList', '管理员列表', 1, 1, 0, '', '', 15, 0, 1446535750, 1, 1),
(17, 'Auth/adminGroup', '用户组列表', 1, 1, 0, '', '', 15, 1, 1446535750, 1, 1),
(18, 'Auth/adminRule', '菜单管理', 1, 1, 0, '', '', 15, 2, 1446535750, 1, 1),
(27, 'Users', '会员管理', 1, 1, 0, 'icon-user', '', 0, 3, 1447231507, 1, 1),
(28, 'Function', '网站功能', 1, 1, 0, 'icon-cog', '', 0, 7, 1447231590, 1, 1),
(29, 'Users/index', '会员列表', 1, 1, 0, '', '', 27, 10, 1447232085, 1, 1),
(31, 'Link/index', '友情链接', 1, 1, 0, '', '', 28, 2, 1447232183, 0, 1),
(32, 'Link/add', '操作-添加', 1, 1, 0, '', '', 31, 1, 1447639935, 0, 0),
(38, 'Users/userGroup', '会员组', 1, 1, 0, '', '', 27, 50, 1448413248, 1, 1),
(45, 'Ad/index', '广告管理', 1, 1, 0, '', '', 28, 3, 1450314297, 1, 1),
(46, 'Ad/type', '广告位管理', 1, 1, 0, '', '', 28, 4, 1450314324, 1, 1),
(48, 'Message/index', '留言管理', 1, 1, 0, '', '', 28, 1, 1451267354, 0, 1),
(108, 'Auth/ruleAdd', '操作-添加', 1, 1, 0, '', '', 18, 0, 1461550835, 1, 0),
(109, 'Auth/ruleState', '操作-状态', 1, 1, 0, '', '', 18, 5, 1461550949, 1, 0),
(110, 'Auth/ruleTz', '操作-验证', 1, 1, 0, '', '', 18, 6, 1461551129, 1, 0),
(111, 'Auth/ruleorder', '操作-排序', 1, 1, 0, '', '', 18, 7, 1461551263, 1, 0),
(112, 'Auth/ruleDel', '操作-删除', 1, 1, 0, '', '', 18, 4, 1461551536, 1, 0),
(114, 'Auth/ruleEdit', '操作-修改', 1, 1, 0, '', '', 18, 2, 1461551913, 1, 0),
(116, 'Auth/groupEdit', '操作-修改', 1, 1, 0, '', '', 17, 3, 1461552326, 1, 0),
(117, 'Auth/groupDel', '操作-删除', 1, 1, 0, '', '', 17, 30, 1461552349, 1, 0),
(118, 'Auth/groupAccess', '操作-权限', 1, 1, 0, '', '', 17, 40, 1461552404, 1, 0),
(119, 'Auth/adminAdd', '操作-添加', 1, 1, 0, '', '', 16, 0, 1461553162, 1, 0),
(120, 'Auth/adminEdit', '操作-修改', 1, 1, 0, '', '', 16, 2, 1461554130, 1, 0),
(121, 'Auth/adminDel', '操作-删除', 1, 1, 0, '', '', 16, 4, 1461554152, 1, 0),
(126, 'Database/export', '操作-备份', 1, 1, 0, '', '', 5, 1, 1461550835, 1, 0),
(127, 'Database/optimize', '操作-优化', 1, 1, 0, '', '', 5, 1, 1461550835, 1, 0),
(128, 'Database/repair', '操作-修复', 1, 1, 0, '', '', 5, 1, 1461550835, 1, 0),
(129, 'Database/delSqlFiles', '操作-删除', 1, 1, 0, '', '', 4, 3, 1461550835, 1, 0),
(236, 'Category/del', '操作-删除', 1, 1, 0, '', '', 9, 5, 1497424900, 0, 0),
(230, 'Database/import', '操作-还原', 1, 1, 0, '', '', 4, 1, 1497423595, 0, 0),
(145, 'Auth/adminState', '操作-状态', 1, 1, 0, '', '', 16, 5, 1461550835, 1, 0),
(149, 'Auth/groupAdd', '操作-添加', 1, 1, 0, '', '', 17, 1, 1461550835, 1, 0),
(151, 'Auth/groupRunaccess', '操作-权存', 1, 1, 0, '', '', 17, 50, 1461550835, 1, 0),
(234, 'Category/insert', '操作-添存', 1, 1, 0, '', '', 9, 2, 1497424143, 0, 0),
(240, 'Module/del', '操作-删除', 1, 1, 0, '', '', 190, 4, 1497425850, 0, 0),
(239, 'Module/moduleState', '操作-状态', 1, 1, 0, '', '', 190, 5, 1497425764, 0, 0),
(238, 'page/edit', '单页编辑', 1, 1, 0, '', '', 7, 2, 1497425142, 0, 0),
(237, 'Category/cOrder', '操作-排序', 1, 1, 0, '', '', 9, 6, 1497424979, 0, 0),
(161, 'Users/usersState', '操作-状态', 1, 1, 0, '', '', 29, 1, 1461550835, 1, 0),
(162, 'Users/delall', '操作-全部删除', 1, 1, 0, '', '', 29, 4, 1461550835, 1, 0),
(163, 'Users/edit', '操作-编辑', 1, 1, 0, '', '', 29, 2, 1461550835, 1, 0),
(164, 'Users/usersDel', '操作-删除', 1, 1, 0, '', '', 29, 3, 1461550835, 1, 0),
(247, 'Message/del', '操作-删除', 1, 1, 0, '', '', 48, 1, 1497427449, 0, 0),
(166, 'Users/groupOrder', '操作-排序', 1, 1, 0, '', '', 38, 50, 1461550835, 1, 0),
(167, 'Users/groupAdd', '操作-添加', 1, 1, 0, '', '', 38, 10, 1461550835, 1, 0),
(169, 'Users/groupDel', '操作-删除', 1, 1, 0, '', '', 38, 30, 1461550835, 1, 0),
(170, 'Ad/add', '操作-添加', 1, 1, 0, '', '', 45, 1, 1461550835, 1, 0),
(171, 'Ad/edit', '操作-修改', 1, 1, 0, '', '', 45, 2, 1461550835, 1, 0),
(173, 'Ad/del', '操作-删除', 1, 1, 0, '', '', 45, 5, 1461550835, 1, 0),
(174, 'Ad/adOrder', '操作-排序', 1, 1, 0, '', '', 45, 4, 1461550835, 1, 0),
(175, 'Ad/editState', '操作-状态', 1, 1, 0, '', '', 45, 3, 1461550835, 1, 0),
(176, 'Ad/addType', '操作-添加', 1, 1, 0, '', '', 46, 1, 1461550835, 1, 0),
(252, 'Template/edit', '操作-编辑', 1, 1, 0, '', '', 197, 3, 1497428906, 0, 0),
(178, 'Ad/delType', '操作-删除', 1, 1, 0, '', '', 46, 4, 1461550835, 1, 0),
(179, 'Ad/typeOrder', '操作-排序', 1, 1, 0, '', '', 46, 3, 1461550835, 1, 0),
(181, 'Auth/groupState', '操作-状态', 1, 1, 0, '', '', 17, 50, 1461834340, 1, 0),
(182, 'Users/groupEdit', '操作-修改', 1, 1, 0, '', '', 38, 15, 1461834780, 1, 0),
(183, 'Ad/editType', '操作-修改', 1, 1, 0, '', '', 46, 2, 1461834988, 1, 0),
(189, 'Module', '模型管理', 1, 1, 0, 'icon-ungroup', '', 0, 9, 1466825363, 0, 1),
(190, 'Module/index', '模型列表', 1, 1, 0, '', '', 189, 1, 1466826681, 0, 1),
(192, 'Module/edit', '操作-修改', 1, 1, 0, '', '', 190, 2, 1467007920, 0, 0),
(193, 'Module/add', '操作-添加', 1, 1, 0, '', '', 190, 1, 1467007955, 0, 0),
(196, 'Template', '模版管理', 1, 1, 0, 'icon-embed2', '', 0, 8, 1481857304, 0, 1),
(197, 'Template/index', '模版管理', 1, 1, 0, '', '', 196, 1, 1481857540, 0, 1),
(198, 'Template/insert', '操作-添存', 1, 1, 0, '', '', 197, 2, 1481857587, 0, 0),
(202, 'Template/add', '操作-添加', 1, 1, 0, '', '', 197, 1, 1481859447, 0, 0),
(203, 'Debris/index', '碎片管理', 1, 1, 0, '', '', 196, 2, 1484797759, 0, 1),
(204, 'Debris/edit', '操作-编辑', 1, 1, 0, '', '', 203, 2, 1484797849, 0, 0),
(205, 'Debris/add', '操作-添加', 1, 1, 0, '', '', 203, 1, 1484797878, 0, 0),
(206, 'Wechat', '微信管理', 1, 1, 0, 'icon-bubbles2', '', 0, 10, 1487063570, 0, 1),
(207, 'Wechat/config', '公众号管理', 1, 1, 0, '', '', 206, 1, 1487063705, 0, 1),
(208, 'Wechat/menu', '菜单管理', 1, 1, 0, '', '', 206, 2, 1487063765, 0, 1),
(209, 'Wechat/materialmessage', '消息素材', 1, 1, 0, '', '', 206, 3, 1487063834, 0, 1),
(212, 'Wechat/weixin', '操作-设置', 1, 1, 0, '', '', 207, 1, 1487064541, 0, 0),
(213, 'Wechat/addMenu', '操作-添加', 1, 1, 0, '', '', 208, 1, 1487149151, 0, 0),
(214, 'Wechat/editText', '操作-编辑', 1, 1, 0, '', '', 209, 2, 1487233984, 0, 0),
(215, 'Wechat/addText', '操作-添加', 1, 1, 0, '', '', 209, 1, 1487234062, 0, 0),
(232, 'Database/downFile', '操作-下载', 1, 1, 0, '', '', 4, 2, 1497423744, 0, 0),
(235, 'Category/catUpdate', '操作-该存', 1, 1, 0, '', '', 9, 4, 1497424301, 0, 0),
(241, 'Module/field', '模型字段', 1, 1, 0, '', '', 190, 6, 1497425972, 0, 0),
(242, 'Module/fieldStatus', '操作-状态', 1, 1, 0, '', '', 241, 4, 1497426044, 0, 0),
(243, 'Module/fieldAdd', '操作-添加', 1, 1, 0, '', '', 241, 1, 1497426089, 0, 0),
(244, 'Module/fieldEdit', '操作-修改', 1, 1, 0, '', '', 241, 2, 1497426134, 0, 0),
(245, 'Module/listOrder', '操作-排序', 1, 1, 0, '', '', 241, 3, 1497426179, 0, 0),
(246, 'Module/fieldDel', '操作-删除', 1, 1, 0, '', '', 241, 5, 1497426241, 0, 0),
(248, 'Message/delall', '操作-删除全部', 1, 1, 0, '', '', 48, 2, 1497427534, 0, 0),
(249, 'Link/edit', '操作-编辑', 1, 1, 0, '', '', 31, 2, 1497427694, 0, 0),
(250, 'Link/linkState', '操作-状态', 1, 1, 0, '', '', 31, 3, 1497427734, 0, 0),
(251, 'Link/del', '操作-删除', 1, 1, 0, '', '', 31, 4, 1497427780, 0, 0),
(253, 'Template/update', '操作-改存', 1, 1, 0, '', '', 197, 4, 1497428951, 0, 0),
(254, 'Template/delete', '操作-删除', 1, 1, 0, '', '', 197, 5, 1497429018, 0, 0),
(255, 'Template/images', '媒体文件管理', 1, 1, 0, '', '', 197, 6, 1497429157, 0, 0),
(256, 'Template/imgDel', '操作-文件删除', 1, 1, 0, '', '', 255, 1, 1497429217, 0, 0),
(257, 'Debris/del', '操作-删除', 1, 1, 0, '', '', 203, 3, 1497429416, 0, 0),
(258, 'Wechat/editMenu', '操作-编辑', 1, 1, 0, '', '', 208, 2, 1497429671, 0, 0),
(259, 'Wechat/menuOrder', '操作-排序', 1, 1, 0, '', '', 208, 3, 1497429707, 0, 0),
(260, 'Wechat/menuState', '操作-状态', 1, 1, 0, '', '', 208, 4, 1497429764, 0, 0),
(261, 'Wechat/delMenu', '操作-删除', 1, 1, 0, '', '', 208, 5, 1497429822, 0, 0),
(262, 'Wechat/createMenu', '操作-生成菜单', 1, 1, 0, '', '', 208, 6, 1497429886, 0, 0),
(263, 'Wechat/delText', '操作-删除', 1, 1, 0, '', '', 209, 3, 1497430020, 0, 0),
(265, 'Donation/index', '捐赠管理', 1, 1, 0, '', '', 28, 5, 1498101716, 0, 1),
(273, 'Wechat/replay', '回复设置', 1, 1, 0, '', '', 206, 4, 1508215988, 0, 1),
(267, 'Plugin/index', '插件管理', 1, 1, 1, 'icon-power-cord', '', 0, 60, 1501466560, 0, 1),
(269, 'Plugin/index', '第三方', 1, 1, 1, '', '', 267, 1, 1501466732, 0, 1),
(270, 'System/email', '邮箱配置', 1, 1, 0, '', '', 1, 2, 1502331829, 0, 1),
(272, 'Debris/type', '碎片分类', 1, 1, 1, '', '', 196, 3, 1504082720, 0, 1),
(280, 'orders', '订单管理', 1, 1, 0, 'icon-cart', '', 0, 4, 1544597485, NULL, 1),
(281, 'orders/ordersList', '订单列表', 1, 1, 1, '', '', 280, 1, 1544598401, NULL, 1),
(282, 'pays', '支付管理', 1, 1, 1, 'icon-coin-dollar', '', 0, 5, 1544598498, NULL, 1),
(283, 'pays/payment', '支付方式', 1, 1, 1, '', '', 282, 50, 1544598641, NULL, 1),
(284, 'money', '积分管理', 1, 1, 1, 'icon-credit-card', '', 0, 6, 1544599076, NULL, 1),
(285, 'money/money', '积分兑换', 1, 1, 1, '', '', 284, 1, 1544599147, NULL, 1);

-- --------------------------------------------------------

--
-- 表的结构 `clt_category`
--

CREATE TABLE IF NOT EXISTS `clt_category` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `catname` varchar(255) NOT NULL DEFAULT '',
  `catdir` varchar(30) NOT NULL DEFAULT '',
  `parentdir` varchar(50) NOT NULL DEFAULT '',
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `moduleid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `module` char(24) NOT NULL DEFAULT '',
  `arrparentid` varchar(255) NOT NULL DEFAULT '',
  `arrchildid` varchar(100) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(150) NOT NULL DEFAULT '',
  `keywords` varchar(200) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `sort` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ishtml` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ismenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `image` varchar(100) NOT NULL DEFAULT '',
  `child` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` varchar(100) NOT NULL DEFAULT '',
  `template_list` varchar(20) NOT NULL DEFAULT '',
  `template_show` varchar(20) NOT NULL DEFAULT '',
  `pagesize` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `readgroup` varchar(100) NOT NULL DEFAULT '',
  `listtype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否预览',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`),
  KEY `listorder` (`sort`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- 转存表中的数据 `clt_category`
--

INSERT INTO `clt_category` (`id`, `catname`, `catdir`, `parentdir`, `parentid`, `moduleid`, `module`, `arrparentid`, `arrchildid`, `type`, `title`, `keywords`, `description`, `sort`, `ishtml`, `ismenu`, `hits`, `image`, `child`, `url`, `template_list`, `template_show`, `pagesize`, `readgroup`, `listtype`, `lang`, `is_show`) VALUES
(1, '网站源码', 'sitecode', '', 0, 5, 'download', '0', '1', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(2, '网站模板', 'templates', '', 0, 5, 'download', '0', '2', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(3, '教程', 'course', '', 0, 2, 'article', '0', '3,4,5,6,7,8,9,10,11,12', 0, '', '', '', 0, 0, 1, 0, '', 1, '', '', '', 0, '', 0, 0, 1),
(4, '网页设计', 'course', 'course/', 3, 2, 'article', '0,3', '4', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '', 0, 0, 1),
(5, '数据库', 'database', 'course/', 3, 2, 'article', '0,3', '5', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '', 0, 0, 1),
(6, '服务器', 'server', 'course/', 3, 2, 'article', '0,3', '6', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '', 0, 0, 1),
(7, 'PHP教程', 'php', 'course/', 3, 2, 'article', '0,3', '7', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(8, 'CMS教程', 'cms', 'course/', 3, 2, 'article', '0,3', '8', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(9, '平面设计', 'graphic', 'course/', 3, 2, 'article', '0,3', '9', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(10, 'SEO优化', 'seo', 'course/', 3, 2, 'article', '0,3', '10', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(11, '前端开发', 'front', 'course/', 3, 2, 'article', '0,3', '11', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(12, '工具插件', 'toolsPlus', 'course/', 3, 2, 'article', '0,3', '12', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(13, '网页特效', 'effect', '', 0, 5, 'download', '0', '13', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(14, '资源分享', 'resource', '', 0, 5, 'download', '0', '14', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(15, '站长资讯', 'webmaster', '', 0, 2, 'article', '0', '15', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(16, '定制方案', 'plan', '', 0, 1, 'page', '0', '16', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(17, '二次开发', 'erkai', '', 0, 1, 'page', '0', '17', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(18, '关于我们', 'aboutUs', '', 0, 1, 'page', '0', '18', 0, '', '', '', 0, 0, 0, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(19, '联系我们', 'linkUs', '', 0, 1, 'page', '0', '19', 0, '', '', '', 0, 0, 0, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(20, '视频专区', 'video', '', 0, 3, 'picture', '0', '20', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '1', 0, 0, 1),
(21, '社区', 'forum', '', 0, 1, 'page', '0', '21', 0, '', '', '', 0, 0, 1, 0, '', 0, '', '', '', 0, '1', 0, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `clt_config`
--

CREATE TABLE IF NOT EXISTS `clt_config` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '表id',
  `name` varchar(50) DEFAULT NULL COMMENT '配置的key键名',
  `value` varchar(512) DEFAULT NULL COMMENT '配置的val值',
  `inc_type` varchar(64) DEFAULT NULL COMMENT '配置分组',
  `desc` varchar(50) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=90 ;

--
-- 转存表中的数据 `clt_config`
--

INSERT INTO `clt_config` (`id`, `name`, `value`, `inc_type`, `desc`) VALUES
(16, 'is_mark', '0', 'water', '0'),
(17, 'mark_txt', '', 'water', '0'),
(18, 'mark_img', '/public/upload/public/2017/01-20/10cd966bd5f3549833c09a5c9700a9b8.jpg', 'water', '0'),
(19, 'mark_width', '', 'water', '0'),
(20, 'mark_height', '', 'water', '0'),
(21, 'mark_degree', '54', 'water', '0'),
(22, 'mark_quality', '56', 'water', '0'),
(23, 'sel', '9', 'water', '0'),
(24, 'sms_url', 'https://yunpan.cn/OcRgiKWxZFmjSJ', 'sms', '0'),
(25, 'sms_user', '', 'sms', '0'),
(26, 'sms_pwd', '访问密码 080e', 'sms', '0'),
(27, 'regis_sms_enable', '1', 'sms', '0'),
(28, 'sms_time_out', '1200', 'sms', '0'),
(38, '__hash__', '8d9fea07e44955760d3407524e469255_6ac8706878aa807db7ffb09dd0b02453', 'sms', '0'),
(39, '__hash__', '8d9fea07e44955760d3407524e469255_6ac8706878aa807db7ffb09dd0b02453', 'sms', '0'),
(56, 'sms_appkey', '123456789', 'sms', '0'),
(57, 'sms_secretKey', '123456789', 'sms', '0'),
(58, 'sms_product', 'CLTPHP', 'sms', '0'),
(59, 'sms_templateCode', 'SMS_101234567890', 'sms', '0'),
(60, 'smtp_server', 'smtp.qq.com', 'smtp', '0'),
(61, 'smtp_port', '465', 'smtp', '0'),
(62, 'smtp_user', '115824818@qq.com', 'smtp', '0'),
(63, 'smtp_pwd', 'admin123', 'smtp', '0'),
(64, 'regis_smtp_enable', '1', 'smtp', '0'),
(65, 'test_eamil', '115824818@qq.com', 'smtp', '0'),
(70, 'forget_pwd_sms_enable', '1', 'sms', '0'),
(71, 'bind_mobile_sms_enable', '1', 'sms', '0'),
(72, 'order_add_sms_enable', '1', 'sms', '0'),
(73, 'order_pay_sms_enable', '1', 'sms', '0'),
(74, 'order_shipping_sms_enable', '1', 'sms', '0'),
(88, 'email_id', '模板小筑', 'smtp', '0'),
(89, 'test_eamil_info', ' 您好！这是一封来自模板小筑的测试邮件！', 'smtp', '0');

-- --------------------------------------------------------

--
-- 表的结构 `clt_debris`
--

CREATE TABLE IF NOT EXISTS `clt_debris` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `type_id` int(6) DEFAULT NULL COMMENT '碎片分类ID',
  `title` varchar(120) DEFAULT NULL COMMENT '标题',
  `content` text COMMENT '内容',
  `addtime` int(13) DEFAULT NULL COMMENT '添加时间',
  `sort` int(11) DEFAULT '50' COMMENT '排序',
  `url` varchar(120) DEFAULT '' COMMENT '链接',
  `pic` varchar(120) DEFAULT '' COMMENT '图片',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- 转存表中的数据 `clt_debris`
--

INSERT INTO `clt_debris` (`id`, `type_id`, `title`, `content`, `addtime`, `sort`, `url`, `pic`) VALUES
(15, 1, '我们的差异化', '<p><span style="text-align: center;">CLTPHP内容管理系统给您自由的模型构建权利，让您的想法通过您亲自操作实现。不要再为传统的数据库字段限制而发愁。一步删除，一步增加，您想要的，就是这一步。</span></p>', 1503293255, 1, '', ''),
(16, 1, '完整的建站理念', '<p><span style="text-align: center;">CLTPHP可以轻松构建模型，让数据库随心而动，让内容表单随意而变。模型和栏目的绑定，是为了让前台页面能更好的为您的想法服务，让您不再为建站留下遗憾。</span></p>', 1503293273, 2, '', ''),
(17, 1, '简单、高效、低门槛', '<p><span style="text-align: center;">CLTPHP内容管理系统，全程鼠标操作，不用手动建立数据库，不用画网站结构图，也不用打开编译器。网站后台直接</span><span style="text-align: center;">编辑</span><span style="text-align: center;">模版，让网站建设达到前所未有的极致简单。</span></p>', 1503293291, 3, '', '');

-- --------------------------------------------------------

--
-- 表的结构 `clt_debris_type`
--

CREATE TABLE IF NOT EXISTS `clt_debris_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(120) DEFAULT NULL,
  `sort` int(1) DEFAULT '50',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `clt_debris_type`
--

INSERT INTO `clt_debris_type` (`id`, `title`, `sort`) VALUES
(1, '【首页】中部碎片', 1);

-- --------------------------------------------------------

--
-- 表的结构 `clt_donation`
--

CREATE TABLE IF NOT EXISTS `clt_donation` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `name` varchar(120) NOT NULL DEFAULT '' COMMENT '用户名',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '捐赠金额',
  `addtime` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- 转存表中的数据 `clt_donation`
--

INSERT INTO `clt_donation` (`id`, `name`, `money`, `addtime`) VALUES
(3, '高飞', '10.00', '1466566714'),
(4, '王磊', '5.50', '1466566733'),
(5, '一匹忧郁的狼', '11.11', '1466566780'),
(6, '神盾', '50.00', '1467517788'),
(7, '赵云的枪', '20.00', '1469582594'),
(8, '王@楠', '5.00', '1473155340'),
(9, '王宁', '10.00', '1473647377'),
(11, '幽鸣', '100.00', '1483080600'),
(12, '得水', '6.60', '1484874321'),
(13, '挨踢男', '50.00', '1485224098'),
(14, '郭强', '6.60', '1486343033'),
(15, '周超', '5.00', '1487570095'),
(16, '栖息地', '20.00', '1488507544'),
(17, '杨萍', '11.00', '1489368971'),
(18, '杨蹦蹦V587', '20.00', '1490608429'),
(19, '锋行天下', '20.00', '1499765536'),
(20, '周伟', '50.00', '1500014307'),
(21, '王者不荣耀', '20.00', '1500368368'),
(22, '老虎的虎', '5.00', '1500867256'),
(23, '老夫子', '20.00', '1501203253'),
(24, '我是传奇', '20.00', '1501567608'),
(25, '秋心', '10.00', '1501807989'),
(31, '晓强', '20.00', '1506742161'),
(32, '再向南飞', '20.00', '1507266070'),
(33, '女王大人', '300.00', '1508807674'),
(34, '在路上', '18.88', '1508851175'),
(35, '玉望灬', '3.00', '1509091826'),
(36, '诚 ', '40.00', '1510121131');

-- --------------------------------------------------------

--
-- 表的结构 `clt_download`
--

CREATE TABLE IF NOT EXISTS `clt_download` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `title` varchar(120) NOT NULL DEFAULT '',
  `title_style` varchar(225) NOT NULL DEFAULT '',
  `thumb` varchar(225) NOT NULL DEFAULT '',
  `keywords` varchar(120) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `content` text NOT NULL,
  `template` varchar(40) NOT NULL DEFAULT '',
  `posid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `readgroup` varchar(100) NOT NULL DEFAULT '',
  `readpoint` smallint(5) NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发布时间',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `files` varchar(80) DEFAULT '' COMMENT '上传文件',
  `ext` varchar(255) NOT NULL DEFAULT 'zip',
  `size` varchar(255) NOT NULL DEFAULT '',
  `downs` int(10) unsigned NOT NULL DEFAULT '0',
  `demourl` varchar(255) DEFAULT '' COMMENT '演示地址',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`sort`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `listorder` (`id`,`catid`,`status`,`sort`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `clt_download`
--

INSERT INTO `clt_download` (`id`, `catid`, `userid`, `username`, `title`, `title_style`, `thumb`, `keywords`, `description`, `content`, `template`, `posid`, `status`, `recommend`, `readgroup`, `readpoint`, `sort`, `hits`, `createtime`, `updatetime`, `files`, `ext`, `size`, `downs`, `demourl`) VALUES
(7, 1, 1, 'admin', 'FastAdmin基于ThinkPHP5和Bootstrap的极速后台开发框架源码', 'color:;font-weight:bold;', '', 'FastAdmin基于ThinkPHP5和Bootstrap的极速后台开发框架源码', 'FastAdmin基于ThinkPHP5和Bootstrap的极速后台开发框架源码', '<p>FastAdmin基于ThinkPHP5和Bootstrap的极速后台开发框架源码</p><p><br></p>', '0', 0, 1, 0, '', 0, 0, 0, 1544601284, 0, '/uploads/20181212/1dd4556d2938d162c39c54b2b86d5056.zip', 'zip', '', 0, 'https://demo.fastadmin.net/admin/index/login.html');

-- --------------------------------------------------------

--
-- 表的结构 `clt_feast`
--

CREATE TABLE IF NOT EXISTS `clt_feast` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `title` varchar(120) DEFAULT '' COMMENT '标题',
  `open` int(1) DEFAULT '1' COMMENT '是否开启',
  `sort` int(4) DEFAULT '50' COMMENT '排序',
  `addtime` varchar(15) DEFAULT NULL COMMENT '添加时间',
  `feast_date` varchar(20) DEFAULT '' COMMENT '节日日期',
  `type` int(1) DEFAULT '1' COMMENT '1阳历 2农历',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='节日列表' AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `clt_feast`
--

INSERT INTO `clt_feast` (`id`, `title`, `open`, `sort`, `addtime`, `feast_date`, `type`) VALUES
(2, '圣诞节', 1, 50, '1513304012', '12-25', 1),
(3, '中秋节', 1, 2, '1513317857', '07-12', 1),
(4, '七夕', 1, 50, '1532420762', '07-24', 1);

-- --------------------------------------------------------

--
-- 表的结构 `clt_feast_element`
--

CREATE TABLE IF NOT EXISTS `clt_feast_element` (
  `id` int(5) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `pid` int(4) DEFAULT NULL COMMENT '父级ID',
  `title` varchar(120) DEFAULT NULL COMMENT '标题',
  `css` text COMMENT 'CSS',
  `js` text COMMENT 'JS',
  `sort` int(5) DEFAULT '50' COMMENT '排序',
  `open` int(1) DEFAULT '1' COMMENT '是否开启',
  `addtime` varchar(15) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='节日元素表' AUTO_INCREMENT=14 ;

--
-- 转存表中的数据 `clt_feast_element`
--

INSERT INTO `clt_feast_element` (`id`, `pid`, `title`, `css`, `js`, `sort`, `open`, `addtime`) VALUES
(1, 2, '内容雪人', '#content-wrapper{position: relative;}\n#top-left img{width: 150px;}\n#top-left{position: absolute;top: 30px;left: -145px;}', '$("#content-wrapper").append("<div id=top-left><img src=/static/feast/christmas/top-left.png></div>");', 1, 1, '1513309235'),
(2, 2, '主页右下角驯鹿', '#body-right-bottom{position: fixed;bottom: 0;right: 20px;z-index:51}\n#body-right-bottom img{width: 400px;}', '$("body").append("<div id=body-right-bottom><img src=/static/feast/christmas/body-right-bottom.png></div>");', 2, 1, '1513309340'),
(3, 2, '主页左下角圣诞树', '#body-left-bottom{position: fixed;bottom: 0;left:0;z-index:51}\n#body-left-bottom img{width: 200px;}', ' $("body").append("<div id=body-left-bottom><img src=/static/feast/christmas/body-left-bottom.png></div>");', 3, 1, '1513309488'),
(4, 2, '主页右上角铃铛', '#body-top-right{position: fixed;top: 0;right:0;z-index: 100;}\n#body-top-right img{width: 120px;}', ' $("body").append("<div id=body-top-right><img src=/static/feast/christmas/body-top-right.png></div>");', 4, 1, '1513309568'),
(5, 2, '主页左中部圣诞老人', '#body-left-center{position: fixed;top: 300px;left: 0;z-index: 100;}\n#body-left-center img{width: 220px;}', '$("body").append("<div id=body-left-center><img src=/static/feast/christmas/body-left-center.png></div>");', 5, 1, '1513309625'),
(6, 2, '下载栏树叶', '.rfeatured-box{position: relative;}\n#right-one-top-right img{width: 60px;}\n#right-one-top-right{position: absolute;top: 0;right: -10px;}', ' $(".featured-box").append("<div id=right-one-top-right><img src=/static/feast/christmas/right-one-top-right.png></div>");', 6, 1, '1513309980'),
(7, 2, '导航栏雪景', 'header{position: relative;}\n#nav-bg img{}\n#nav-bg{position: absolute;bottom: -15px;height:30px;left: 0;width: 100%;background: url("/static/feast/christmas/nav-bg.png")repeat-x; z-index:50}', '$("header").append("<div id=nav-bg><img src=/static/feast/christmas/nav-bg.png></div>");', 7, 1, '1513310236'),
(8, 2, '主页背景', 'body{background: url("/static/feast/christmas/zbg.png") no-repeat 100% 100%;background-size: 100%;}', '', 50, 1, '1513310497'),
(10, 3, '主页左下角房子', '#body-left-bottom{position: fixed;bottom: 0;left:0;}\n#body-left-bottom img{width: 200px;}', ' $("body").append("<div id=body-left-bottom><img src=/static/feast/zhongqiu/body-left-bottom.png></div>");', 50, 1, '1513320275'),
(11, 3, '左上角文字', '#body-top-left{position: fixed;top:0;left0;z-index: 100;}\n#body-top-left img{width: 350px;}', ' $("body").append("<div id=body-top-left><img src=/static/feast/zhongqiu/body-top-left.png?111></div>");', 50, 1, '1513320569'),
(12, 3, '右上角嫦娥', '#body-top-right{position: fixed;top: 0;right:0;z-index: 100;}\n#body-top-right img{width: 300px;}', ' $("body").append("<div id=body-top-right><img src=/static/feast/zhongqiu/body-top-right.png></div>");', 50, 1, '1513321010'),
(13, 4, '右上角喜鹊', '#body-top-right{position: fixed;top: 0;right:0;z-index: 100;}\n#body-top-right img{width: 300px;}', ' $("body").append("<div id=body-top-right><img src=/static/feast/qixi/bird.png></div>");', 1, 1, '1528689869');

-- --------------------------------------------------------

--
-- 表的结构 `clt_field`
--

CREATE TABLE IF NOT EXISTS `clt_field` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `moduleid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `field` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(30) NOT NULL DEFAULT '',
  `tips` varchar(150) NOT NULL DEFAULT '',
  `required` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `minlength` int(10) unsigned NOT NULL DEFAULT '0',
  `maxlength` int(10) unsigned NOT NULL DEFAULT '0',
  `pattern` varchar(255) NOT NULL DEFAULT '',
  `errormsg` varchar(255) NOT NULL DEFAULT '',
  `class` varchar(20) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT '',
  `setup` text,
  `ispost` tinyint(1) NOT NULL DEFAULT '0',
  `unpostgroup` varchar(60) NOT NULL DEFAULT '',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=159 ;

--
-- 转存表中的数据 `clt_field`
--

INSERT INTO `clt_field` (`id`, `moduleid`, `field`, `name`, `tips`, `required`, `minlength`, `maxlength`, `pattern`, `errormsg`, `class`, `type`, `setup`, `ispost`, `unpostgroup`, `sort`, `status`, `issystem`) VALUES
(1, 1, 'title', '标题', '', 1, 1, 80, 'defaul', '标题必须为1-80个字符', 'title', 'title', 'array (\n  ''thumb'' => ''1'',\n  ''style'' => ''1'',\n)', 1, '', 1, 1, 1),
(2, 1, 'hits', '点击次数', '', 0, 0, 8, '', '', '', 'number', 'array (\n  ''size'' => ''10'',\n  ''numbertype'' => ''1'',\n  ''decimaldigits'' => ''0'',\n  ''default'' => ''0'',\n)', 1, '', 8, 0, 0),
(3, 1, 'createtime', '发布时间', '', 1, 0, 0, 'date', '', '', 'datetime', '', 1, '', 97, 1, 1),
(4, 1, 'template', '模板', '', 0, 0, 0, '', '', '', 'template', '', 1, '', 99, 1, 1),
(5, 1, 'status', '状态', '', 0, 0, 0, 'defaul', '', 'status', 'radio', 'array (\n  ''options'' => ''发布|1\n定时发布|0'',\n  ''fieldtype'' => ''varchar'',\n  ''numbertype'' => ''1'',\n  ''default'' => ''1'',\n)', 0, '', 98, 1, 1),
(6, 1, 'content', '内容', '', 1, 0, 0, 'defaul', '', 'content', 'editor', 'array (\n  ''edittype'' => ''wangEditor'',\n)', 0, '', 3, 1, 0),
(7, 2, 'catid', '栏目', '', 1, 1, 6, '', '必须选择一个栏目', '', 'catid', '', 1, '', 1, 1, 1),
(8, 2, 'title', '标题', '', 1, 1, 80, 'defaul', '标题必须为1-80个字符', 'title', 'title', 'array (\n  ''thumb'' => ''1'',\n  ''style'' => ''1'',\n)', 1, '', 2, 1, 1),
(9, 2, 'keywords', '关键词', '', 0, 0, 80, '', '', '', 'text', 'array (\n  ''size'' => ''55'',\n  ''default'' => '''',\n  ''ispassword'' => ''0'',\n  ''fieldtype'' => ''varchar'',\n)', 1, '', 3, 1, 1),
(10, 2, 'description', 'SEO简介', '', 0, 0, 0, '', '', '', 'textarea', 'array (\n  ''fieldtype'' => ''mediumtext'',\n  ''rows'' => ''4'',\n  ''cols'' => ''55'',\n  ''default'' => '''',\n)', 1, '', 4, 1, 1),
(11, 2, 'content', '内容', '', 0, 0, 0, 'defaul', '', 'content', 'editor', 'array (\n  ''edittype'' => ''UEditor'',\n)', 1, '', 5, 1, 1),
(12, 2, 'createtime', '发布时间', '', 1, 0, 0, 'date', '', 'createtime', 'datetime', '', 1, '', 6, 1, 1),
(13, 2, 'recommend', '允许评论', '', 0, 0, 1, '', '', '', 'radio', 'array (\n  ''options'' => ''允许评论|1\r\n不允许评论|0'',\n  ''fieldtype'' => ''tinyint'',\n  ''numbertype'' => ''1'',\n  ''labelwidth'' => '''',\n  ''default'' => '''',\n)', 1, '', 10, 0, 0),
(14, 2, 'readpoint', '阅读收费', '', 0, 0, 5, '', '', '', 'number', 'array (\n  ''size'' => ''5'',\n  ''numbertype'' => ''1'',\n  ''decimaldigits'' => ''0'',\n  ''default'' => ''0'',\n)', 1, '', 11, 0, 0),
(15, 2, 'hits', '点击次数', '', 0, 0, 8, '', '', '', 'number', 'array (\n  ''size'' => ''10'',\n  ''numbertype'' => ''1'',\n  ''decimaldigits'' => ''0'',\n  ''default'' => ''0'',\n)', 1, '', 12, 1, 0),
(16, 2, 'readgroup', '访问权限', '', 0, 0, 0, '', '', '', 'groupid', 'array (\n  ''inputtype'' => ''checkbox'',\n  ''fieldtype'' => ''tinyint'',\n  ''labelwidth'' => ''85'',\n  ''default'' => '''',\n)', 1, '', 13, 1, 1),
(17, 2, 'posid', '推荐位', '', 0, 0, 0, '', '', '', 'posid', '', 1, '', 14, 1, 1),
(18, 2, 'template', '模板', '', 0, 0, 0, '', '', '', 'template', '', 1, '', 15, 1, 1),
(19, 2, 'status', '状态', '', 0, 0, 0, 'defaul', '', 'status', 'radio', 'array (\n  ''options'' => ''发布|1\n定时发布|2'',\n  ''fieldtype'' => ''varchar'',\n  ''numbertype'' => ''1'',\n  ''default'' => ''1'',\n)', 1, '', 7, 1, 1),
(20, 3, 'catid', '栏目', '', 1, 1, 6, '', '必须选择一个栏目', '', 'catid', '', 1, '', 1, 1, 1),
(21, 3, 'title', '标题', '', 1, 1, 80, 'defaul', '标题必须为1-80个字符', '', 'title', 'array (\n  ''thumb'' => ''0'',\n  ''style'' => ''0'',\n)', 1, '', 2, 1, 1),
(22, 3, 'keywords', '关键词', '', 0, 0, 80, '', '', '', 'text', 'array (\n  ''size'' => ''55'',\n  ''default'' => '''',\n  ''ispassword'' => ''0'',\n  ''fieldtype'' => ''varchar'',\n)', 1, '', 3, 1, 1),
(23, 3, 'description', 'SEO简介', '', 0, 0, 0, '', '', '', 'textarea', 'array (\n  ''fieldtype'' => ''mediumtext'',\n  ''rows'' => ''4'',\n  ''cols'' => ''55'',\n  ''default'' => '''',\n)', 1, '', 4, 1, 1),
(24, 3, 'content', '内容', '', 0, 0, 0, 'defaul', '', 'content', 'editor', 'array (\n  ''edittype'' => ''layedit'',\n)', 1, '', 7, 1, 1),
(25, 3, 'createtime', '发布时间', '', 1, 0, 0, 'date', '', '', 'datetime', '', 1, '', 8, 1, 1),
(26, 3, 'recommend', '允许评论', '', 0, 0, 1, '', '', '', 'radio', 'array (\n  ''options'' => ''允许评论|1\r\n不允许评论|0'',\n  ''fieldtype'' => ''tinyint'',\n  ''numbertype'' => ''1'',\n  ''labelwidth'' => '''',\n  ''default'' => '''',\n)', 1, '', 10, 0, 0),
(27, 3, 'readpoint', '阅读收费', '', 0, 0, 5, '', '', '', 'number', 'array (\n  ''size'' => ''5'',\n  ''numbertype'' => ''1'',\n  ''decimaldigits'' => ''0'',\n  ''default'' => ''0'',\n)', 1, '', 11, 0, 0),
(28, 3, 'hits', '点击次数', '', 0, 0, 8, '', '', '', 'number', 'array (\n  ''size'' => ''10'',\n  ''numbertype'' => ''1'',\n  ''decimaldigits'' => ''0'',\n  ''default'' => ''0'',\n)', 1, '', 12, 0, 0),
(29, 3, 'readgroup', '访问权限', '', 0, 0, 0, '', '', '', 'groupid', 'array (\n  ''inputtype'' => ''checkbox'',\n  ''fieldtype'' => ''tinyint'',\n  ''labelwidth'' => ''85'',\n  ''default'' => '''',\n)', 1, '', 13, 0, 1),
(30, 3, 'posid', '推荐位', '', 0, 0, 0, '', '', '', 'posid', '', 1, '', 14, 1, 1),
(31, 3, 'template', '模板', '', 0, 0, 0, '', '', '', 'template', '', 1, '', 15, 1, 1),
(32, 3, 'status', '状态', '', 0, 0, 0, '', '', '', 'radio', 'array (\n  ''options'' => ''发布|1\r\n定时发布|0'',\n  ''fieldtype'' => ''tinyint'',\n  ''numbertype'' => ''1'',\n  ''labelwidth'' => ''75'',\n  ''default'' => ''1'',\n)', 1, '', 9, 1, 1),
(33, 3, 'pic', '图片', '', 1, 0, 0, 'defaul', '', 'pic', 'image', '', 0, '', 5, 1, 0),
(34, 3, 'group', '类型', '', 1, 0, 0, 'defaul', '', 'group', 'select', 'array (\n  ''options'' => ''模型管理|1\n分类管理|2\n内容管理|3'',\n  ''multiple'' => ''0'',\n  ''fieldtype'' => ''varchar'',\n  ''numbertype'' => ''1'',\n  ''size'' => '''',\n  ''default'' => '''',\n)', 0, '', 6, 1, 0),
(35, 4, 'catid', '栏目', '', 1, 1, 6, '', '必须选择一个栏目', '', 'catid', '', 1, '', 1, 1, 1),
(36, 4, 'title', '标题', '', 1, 1, 80, '', '标题必须为1-80个字符', '', 'title', 'array (\n  ''thumb'' => ''1'',\n  ''style'' => ''1'',\n  ''size'' => ''55'',\n)', 1, '', 2, 1, 1),
(37, 4, 'keywords', '关键词', '', 0, 0, 80, '', '', '', 'text', 'array (\n  ''size'' => ''55'',\n  ''default'' => '''',\n  ''ispassword'' => ''0'',\n  ''fieldtype'' => ''varchar'',\n)', 1, '', 3, 1, 1),
(38, 4, 'description', 'SEO简介', '', 0, 0, 0, '', '', '', 'textarea', 'array (\n  ''fieldtype'' => ''mediumtext'',\n  ''rows'' => ''4'',\n  ''cols'' => ''55'',\n  ''default'' => '''',\n)', 1, '', 4, 1, 1),
(39, 4, 'content', '内容', '', 0, 0, 0, 'defaul', '', 'content', 'editor', 'array (\n  ''edittype'' => ''layedit'',\n)', 1, '', 8, 1, 1),
(40, 4, 'createtime', '发布时间', '', 1, 0, 0, 'date', '', '', 'datetime', '', 1, '', 9, 1, 1),
(41, 4, 'status', '状态', '', 0, 0, 0, '', '', '', 'radio', 'array (\n  ''options'' => ''发布|1\r\n定时发布|0'',\n  ''fieldtype'' => ''tinyint'',\n  ''numbertype'' => ''1'',\n  ''labelwidth'' => ''75'',\n  ''default'' => ''1'',\n)', 1, '', 10, 1, 1),
(42, 4, 'recommend', '允许评论', '', 0, 0, 1, '', '', '', 'radio', 'array (\n  ''options'' => ''允许评论|1\r\n不允许评论|0'',\n  ''fieldtype'' => ''tinyint'',\n  ''numbertype'' => ''1'',\n  ''labelwidth'' => '''',\n  ''default'' => '''',\n)', 1, '', 11, 0, 0),
(43, 4, 'readpoint', '阅读收费', '', 0, 0, 5, '', '', '', 'number', 'array (\n  ''size'' => ''5'',\n  ''numbertype'' => ''1'',\n  ''decimaldigits'' => ''0'',\n  ''default'' => ''0'',\n)', 1, '', 12, 0, 0),
(44, 4, 'hits', '点击次数', '', 0, 0, 8, '', '', '', 'number', 'array (\n  ''size'' => ''10'',\n  ''numbertype'' => ''1'',\n  ''decimaldigits'' => ''0'',\n  ''default'' => ''0'',\n)', 1, '', 13, 0, 0),
(45, 4, 'readgroup', '访问权限', '', 0, 0, 0, '', '', '', 'groupid', 'array (\n  ''inputtype'' => ''checkbox'',\n  ''fieldtype'' => ''tinyint'',\n  ''labelwidth'' => ''85'',\n  ''default'' => '''',\n)', 1, '', 14, 0, 1),
(46, 4, 'posid', '推荐位', '', 0, 0, 0, '', '', '', 'posid', '', 1, '', 15, 1, 1),
(47, 4, 'template', '模板', '', 0, 0, 0, '', '', '', 'template', '', 1, '', 16, 1, 1),
(48, 4, 'price', '价格', '', 1, 0, 0, 'defaul', '', 'price', 'number', 'array (\n  ''size'' => '''',\n  ''numbertype'' => ''1'',\n  ''decimaldigits'' => ''2'',\n  ''default'' => ''0.00'',\n)', 0, '', 5, 1, 0),
(49, 4, 'xinghao', '型号', '', 0, 0, 0, 'defaul', '', '', 'text', 'array (\n  ''default'' => '''',\n  ''ispassword'' => ''0'',\n  ''fieldtype'' => ''varchar'',\n)', 0, '', 6, 1, 0),
(50, 4, 'pics', '图组', '', 0, 0, 0, 'defaul', '', 'pics', 'images', '', 0, '', 7, 1, 0),
(51, 5, 'catid', '栏目', '', 1, 1, 6, '', '必须选择一个栏目', '', 'catid', '', 1, '', 1, 1, 1),
(52, 5, 'title', '标题', '', 1, 1, 80, '', '标题必须为1-80个字符', '', 'title', 'array (\n  ''thumb'' => ''1'',\n  ''style'' => ''1'',\n  ''size'' => ''55'',\n)', 1, '', 2, 1, 1),
(53, 5, 'keywords', '关键词', '', 0, 0, 80, '', '', '', 'text', 'array (\n  ''size'' => ''55'',\n  ''default'' => '''',\n  ''ispassword'' => ''0'',\n  ''fieldtype'' => ''varchar'',\n)', 1, '', 3, 1, 1),
(54, 5, 'description', 'SEO简介', '', 0, 0, 0, '', '', '', 'textarea', 'array (\n  ''fieldtype'' => ''mediumtext'',\n  ''rows'' => ''4'',\n  ''cols'' => ''55'',\n  ''default'' => '''',\n)', 1, '', 4, 1, 1),
(55, 5, 'content', '内容', '', 0, 0, 0, 'defaul', '', 'content', 'editor', 'array (\n  ''edittype'' => ''layedit'',\n)', 1, '', 10, 1, 1),
(56, 5, 'createtime', '发布时间', '', 1, 0, 0, 'date', '', 'createtime', 'datetime', '', 1, '', 11, 1, 1),
(57, 5, 'status', '状态', '', 0, 0, 0, '', '', '', 'radio', 'array (\n  ''options'' => ''发布|1\r\n定时发布|0'',\n  ''fieldtype'' => ''tinyint'',\n  ''numbertype'' => ''1'',\n  ''labelwidth'' => ''75'',\n  ''default'' => ''1'',\n)', 1, '', 12, 1, 1),
(58, 5, 'recommend', '允许评论', '', 0, 0, 1, '', '', '', 'radio', 'array (\n  ''options'' => ''允许评论|1\r\n不允许评论|0'',\n  ''fieldtype'' => ''tinyint'',\n  ''numbertype'' => ''1'',\n  ''labelwidth'' => '''',\n  ''default'' => '''',\n)', 1, '', 13, 0, 0),
(59, 5, 'readpoint', '阅读收费', '', 0, 0, 5, '', '', '', 'number', 'array (\n  ''size'' => ''5'',\n  ''numbertype'' => ''1'',\n  ''decimaldigits'' => ''0'',\n  ''default'' => ''0'',\n)', 1, '', 14, 0, 0),
(60, 5, 'hits', '点击次数', '', 0, 0, 8, '', '', '', 'number', 'array (\n  ''size'' => ''10'',\n  ''numbertype'' => ''1'',\n  ''decimaldigits'' => ''0'',\n  ''default'' => ''0'',\n)', 1, '', 15, 0, 0),
(61, 5, 'readgroup', '访问权限', '', 0, 0, 0, '', '', '', 'groupid', 'array (\n  ''inputtype'' => ''checkbox'',\n  ''fieldtype'' => ''tinyint'',\n  ''labelwidth'' => ''85'',\n  ''default'' => '''',\n)', 1, '', 16, 0, 1),
(62, 5, 'posid', '推荐位', '', 0, 0, 0, '', '', '', 'posid', '', 1, '', 17, 1, 1),
(63, 5, 'template', '模板', '', 0, 0, 0, '', '', '', 'template', '', 1, '', 18, 1, 1),
(64, 5, 'files', '上传文件', '', 0, 0, 0, 'defaul', '', 'files', 'file', 'array (\n  ''upload_allowext'' => ''zip,rar,doc,ppt,pdf'',\n)', 0, '', 6, 1, 0),
(65, 5, 'ext', '文档类型', '', 0, 0, 0, 'defaul', '', 'ext', 'text', 'array (\n  ''default'' => ''zip'',\n  ''ispassword'' => ''0'',\n  ''fieldtype'' => ''varchar'',\n)', 0, '', 7, 1, 0),
(66, 5, 'size', '文档大小', '', 0, 0, 0, 'defaul', '', 'size', 'text', 'array (\n  ''default'' => '''',\n  ''ispassword'' => ''0'',\n  ''fieldtype'' => ''varchar'',\n)', 0, '', 8, 1, 0),
(67, 5, 'downs', '下载次数', '', 0, 0, 0, 'defaul', '', '', 'number', 'array (\n  ''size'' => '''',\n  ''numbertype'' => ''1'',\n  ''decimaldigits'' => ''0'',\n  ''default'' => '''',\n)', 0, '', 9, 1, 0),
(68, 6, 'title', '标题', '', 1, 1, 80, '', '标题必须为1-80个字符', '', 'title', 'array (\n  ''thumb'' => ''1'',\n  ''style'' => ''1'',\n  ''size'' => ''55'',\n)', 1, '', 2, 1, 1),
(69, 6, 'hits', '点击次数', '', 0, 0, 8, '', '', '', 'number', 'array (\n  ''size'' => ''10'',\n  ''numbertype'' => ''1'',\n  ''decimaldigits'' => ''0'',\n  ''default'' => ''0'',\n)', 1, '', 6, 0, 0),
(70, 6, 'createtime', '发布时间', '', 1, 0, 0, 'date', '', '', 'datetime', '', 1, '', 4, 1, 1),
(71, 6, 'template', '模板', '', 0, 0, 0, '', '', '', 'template', '', 1, '', 7, 1, 1),
(72, 6, 'status', '状态', '', 0, 0, 0, '', '', '', 'radio', 'array (\n  ''options'' => ''发布|1\r\n定时发布|0'',\n  ''fieldtype'' => ''tinyint'',\n  ''numbertype'' => ''1'',\n  ''labelwidth'' => ''75'',\n  ''default'' => ''1'',\n)', 1, '', 5, 1, 1),
(73, 6, 'catid', '分类', '', 1, 0, 0, 'defaul', '', 'catid', 'catid', '', 0, '', 1, 1, 0),
(74, 6, 'info', '简介', '', 1, 0, 0, 'defaul', '', 'info', 'editor', 'array (\n  ''edittype'' => ''layedit'',\n)', 0, '', 3, 1, 0),
(75, 2, 'copyfrom', '来源', '', 0, 0, 0, 'defaul', '', 'copyfrom', 'text', 'array (\n  ''default'' => ''CLTPHP'',\n  ''ispassword'' => ''0'',\n  ''fieldtype'' => ''varchar'',\n)', 0, '', 8, 1, 0),
(76, 2, 'fromlink', '来源网址', '', 0, 0, 0, 'defaul', '', 'fromlink', 'text', 'array (\n  ''default'' => ''http://www.cltphp.com/'',\n  ''ispassword'' => ''0'',\n  ''fieldtype'' => ''varchar'',\n)', 0, '', 9, 1, 0),
(158, 5, 'demourl', '演示地址', '', 0, 0, 0, 'url', '', 'demourl', 'text', 'array (\n  ''default'' => '''',\n  ''ispassword'' => ''0'',\n  ''fieldtype'' => ''varchar'',\n)', 0, '', 5, 1, 0);

-- --------------------------------------------------------

--
-- 表的结构 `clt_link`
--

CREATE TABLE IF NOT EXISTS `clt_link` (
  `link_id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '链接名称',
  `url` varchar(200) NOT NULL COMMENT '链接URL',
  `type_id` tinyint(4) DEFAULT NULL COMMENT '所属栏目ID',
  `qq` varchar(20) NOT NULL COMMENT '联系QQ',
  `sort` int(5) NOT NULL DEFAULT '50' COMMENT '排序',
  `addtime` int(11) NOT NULL COMMENT '添加时间',
  `open` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0禁用1启用',
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- 转存表中的数据 `clt_link`
--

INSERT INTO `clt_link` (`link_id`, `name`, `url`, `type_id`, `qq`, `sort`, `addtime`, `open`) VALUES
(10, 'PHP技术博客', 'http://www.mobanw.com/', 0, '1158624818', 1, 1495183645, 1);

-- --------------------------------------------------------

--
-- 表的结构 `clt_message`
--

CREATE TABLE IF NOT EXISTS `clt_message` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT '' COMMENT '留言标题',
  `tel` varchar(15) NOT NULL DEFAULT '' COMMENT '留言电话',
  `addtime` varchar(15) NOT NULL COMMENT '留言时间',
  `open` tinyint(2) NOT NULL DEFAULT '0' COMMENT '1=审核 0=不审核',
  `ip` varchar(50) DEFAULT '' COMMENT '留言者IP',
  `content` longtext NOT NULL COMMENT '留言内容',
  `name` varchar(60) NOT NULL DEFAULT '' COMMENT '用户名',
  `email` varchar(50) NOT NULL COMMENT '留言邮箱',
  PRIMARY KEY (`message_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=97 ;

--
-- 转存表中的数据 `clt_message`
--

INSERT INTO `clt_message` (`message_id`, `title`, `tel`, `addtime`, `open`, `ip`, `content`, `name`, `email`) VALUES
(92, '呵呵', '', '1528851199', 0, '127.0.0.1', '为什么还不更新？', 'chichu', '1109305987@qq.com'),
(93, '11', '', '1530629400', 0, '127.0.0.1', '11', '11', '11'),
(94, '11', '', '1530777448', 0, '127.0.0.1', '11', '11', '11'),
(95, '11', '', '1542781283', 0, '127.0.0.1', '<p>111</p>', '11', '110@qq.com');

-- --------------------------------------------------------

--
-- 表的结构 `clt_module`
--

CREATE TABLE IF NOT EXISTS `clt_module` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(200) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `listfields` varchar(255) NOT NULL DEFAULT '',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- 转存表中的数据 `clt_module`
--

INSERT INTO `clt_module` (`id`, `title`, `name`, `description`, `type`, `issystem`, `listfields`, `sort`, `status`) VALUES
(1, '单页模型', 'page', '单页面', 1, 0, '*', 0, 1),
(2, '文章模型', 'article', '新闻文章', 1, 0, '*', 0, 1),
(3, '图片模型', 'picture', '图片展示', 1, 0, '*', 0, 1),
(4, '产品模型', 'product', '产品展示', 1, 0, '*', 0, 1),
(5, '下载模型', 'download', '文件下载', 1, 0, '*', 0, 1),
(6, '团队模型', 'team', '员工展示', 1, 0, '*', 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `clt_oauth`
--

CREATE TABLE IF NOT EXISTS `clt_oauth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '用户id',
  `type` varchar(50) DEFAULT NULL COMMENT '账号类型',
  `openid` varchar(120) DEFAULT NULL COMMENT '第三方唯一标示',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `clt_page`
--

CREATE TABLE IF NOT EXISTS `clt_page` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(80) NOT NULL DEFAULT '',
  `title_style` varchar(225) NOT NULL DEFAULT '',
  `thumb` varchar(225) NOT NULL DEFAULT '',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `status` varchar(255) NOT NULL DEFAULT '1',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `content` text COMMENT '内容',
  `template` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=59 ;

--
-- 转存表中的数据 `clt_page`
--

INSERT INTO `clt_page` (`id`, `title`, `title_style`, `thumb`, `hits`, `status`, `userid`, `username`, `sort`, `createtime`, `updatetime`, `lang`, `content`, `template`) VALUES
(18, '关于我们', '', '', 0, '1', 0, '', 0, 0, 0, 0, '', ''),
(19, '联系我们', '', '', 0, '1', 0, '', 0, 0, 0, 0, '', ''),
(21, '社区', '', '', 0, '1', 0, '', 0, 0, 0, 0, '', ''),
(1, '源码下载', '', '', 0, '1', 0, '', 0, 0, 0, 0, '', ''),
(11, '前端开发', '', '', 0, '1', 0, '', 0, 0, 0, 0, '', ''),
(12, '工具插件', '', '', 0, '1', 0, '', 0, 0, 0, 0, '', ''),
(16, '解决方案', '', '', 0, '1', 0, '', 0, 0, 0, 0, '', ''),
(17, '二次开发', '', '', 0, '1', 0, '', 0, 0, 0, 0, '', '');

-- --------------------------------------------------------

--
-- 表的结构 `clt_picture`
--

CREATE TABLE IF NOT EXISTS `clt_picture` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `title` varchar(80) NOT NULL DEFAULT '',
  `keywords` varchar(120) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `content` text NOT NULL,
  `template` varchar(40) NOT NULL DEFAULT '',
  `posid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `readgroup` varchar(100) NOT NULL DEFAULT '',
  `readpoint` smallint(5) NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `pic` varchar(80) NOT NULL DEFAULT '',
  `group` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`sort`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `listorder` (`id`,`catid`,`status`,`sort`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- --------------------------------------------------------

--
-- 表的结构 `clt_plugin`
--

CREATE TABLE IF NOT EXISTS `clt_plugin` (
  `code` varchar(13) DEFAULT NULL COMMENT '插件编码',
  `name` varchar(55) DEFAULT NULL COMMENT '中文名字',
  `version` varchar(255) DEFAULT NULL COMMENT '插件的版本',
  `author` varchar(30) DEFAULT NULL COMMENT '插件作者',
  `config` text COMMENT '配置信息',
  `config_value` text COMMENT '配置值信息',
  `desc` varchar(255) DEFAULT NULL COMMENT '插件描述',
  `status` tinyint(1) DEFAULT '0' COMMENT '是否启用',
  `type` varchar(50) DEFAULT NULL COMMENT '插件类型 payment支付 login 登陆 shipping物流',
  `icon` varchar(255) DEFAULT NULL COMMENT '图标',
  `bank_code` text COMMENT '网银配置信息',
  `scene` tinyint(1) DEFAULT '0' COMMENT '使用场景 0 PC+手机 1 手机 2 PC'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `clt_plugin`
--

INSERT INTO `clt_plugin` (`code`, `name`, `version`, `author`, `config`, `config_value`, `desc`, `status`, `type`, `icon`, `bank_code`, `scene`) VALUES
('qq', 'QQ登陆', '1.0', 'CLTPHP', 'a:5:{i:0;a:4:{s:4:"name";s:5:"appid";s:5:"label";s:5:"appid";s:4:"type";s:4:"text";s:5:"value";s:0:"";}i:1;a:4:{s:4:"name";s:6:"appkey";s:5:"label";s:6:"appkey";s:4:"type";s:4:"text";s:5:"value";s:0:"";}i:2;a:4:{s:4:"name";s:8:"callback";s:5:"label";s:12:"回调地址";s:4:"type";s:4:"text";s:5:"value";s:37:"http://cltdemo.test/index/callback/qq";}i:3;a:4:{s:4:"name";s:5:"scope";s:5:"label";s:12:"获取字段";s:4:"type";s:8:"textarea";s:5:"value";s:225:"get_user_info,add_share,list_album,add_album,upload_pic,add_topic,add_one_blog,add_weibo,check_page_fans,add_t,add_pic_t,del_t,get_repost_list,get_info,get_other_info,get_fanslist,get_idolist,add_idol,del_idol,get_tenpay_addr";}i:4;a:4:{s:4:"name";s:11:"errorReport";s:5:"label";s:12:"错误报告";s:4:"type";s:4:"text";s:5:"value";s:4:"true";}}', 'a:5:{s:5:"appid";s:0:"";s:6:"appkey";s:0:"";s:8:"callback";s:37:"http://cltdemo.test/index/callback/qq";s:5:"scope";s:225:"get_user_info,add_share,list_album,add_album,upload_pic,add_topic,add_one_blog,add_weibo,check_page_fans,add_t,add_pic_t,del_t,get_repost_list,get_info,get_other_info,get_fanslist,get_idolist,add_idol,del_idol,get_tenpay_addr";s:11:"errorReport";s:4:"true";}', 'QQ登陆插件 ', 1, 'login', 'logo.png', 's:0:"";', 0),
('changyan', '畅言评论', '1.0', 'CLTPHP', 'a:3:{i:0;a:4:{s:4:"name";s:6:"app_id";s:5:"label";s:6:"app_id";s:4:"type";s:4:"text";s:5:"value";s:0:"";}i:1;a:4:{s:4:"name";s:7:"app_key";s:5:"label";s:7:"app_key";s:4:"type";s:4:"text";s:5:"value";s:0:"";}i:2;a:4:{s:4:"name";s:6:"config";s:5:"label";s:6:"config";s:4:"type";s:4:"text";s:5:"value";s:0:"";}}', 'a:8:{s:5:"appid";s:0:"";s:6:"appkey";s:0:"";s:8:"callback";s:37:"http://cltdemo.test/index/callback/qq";s:5:"scope";s:225:"get_user_info,add_share,list_album,add_album,upload_pic,add_topic,add_one_blog,add_weibo,check_page_fans,add_t,add_pic_t,del_t,get_repost_list,get_info,get_other_info,get_fanslist,get_idolist,add_idol,del_idol,get_tenpay_addr";s:11:"errorReport";s:4:"true";s:6:"app_id";s:0:"";s:7:"app_key";s:0:"";s:6:"config";s:0:"";}', '畅言评论插件 ', 1, 'msg', 'logo.png', 's:0:"";', 0);

-- --------------------------------------------------------

--
-- 表的结构 `clt_posid`
--

CREATE TABLE IF NOT EXISTS `clt_posid` (
  `id` tinyint(2) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `sort` tinyint(2) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `clt_posid`
--

INSERT INTO `clt_posid` (`id`, `name`, `sort`) VALUES
(1, '首页推荐', 0),
(2, '当前分类推荐', 0);

-- --------------------------------------------------------

--
-- 表的结构 `clt_product`
--

CREATE TABLE IF NOT EXISTS `clt_product` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `title` varchar(120) NOT NULL DEFAULT '',
  `title_style` varchar(225) NOT NULL DEFAULT '',
  `thumb` varchar(225) NOT NULL DEFAULT '',
  `keywords` varchar(120) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `content` text NOT NULL,
  `template` varchar(40) NOT NULL DEFAULT '',
  `posid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `readgroup` varchar(100) NOT NULL DEFAULT '',
  `readpoint` smallint(5) NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `xinghao` varchar(255) NOT NULL DEFAULT '',
  `pics` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`sort`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `listorder` (`id`,`catid`,`status`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `clt_region`
--

CREATE TABLE IF NOT EXISTS `clt_region` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(120) NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=59 ;

--
-- 转存表中的数据 `clt_region`
--

INSERT INTO `clt_region` (`id`, `pid`, `name`, `type`) VALUES
(1, 0, '中国', 0),
(2, 1, '北京', 1),
(3, 1, '安徽', 1),
(4, 1, '福建', 1),
(5, 1, '甘肃', 1),
(6, 1, '广东', 1),
(7, 1, '广西', 1),
(8, 1, '贵州', 1),
(9, 1, '海南', 1),
(10, 1, '河北', 1),
(11, 1, '河南', 1),
(12, 1, '黑龙江', 1),
(13, 1, '湖北', 1),
(14, 1, '湖南', 1),
(15, 1, '吉林', 1),
(16, 1, '江苏', 1),
(17, 1, '江西', 1),
(18, 1, '辽宁', 1),
(19, 1, '内蒙古', 1),
(20, 1, '宁夏', 1),
(21, 1, '青海', 1),
(22, 1, '山东', 1),
(23, 1, '山西', 1),
(24, 1, '陕西', 1),
(25, 1, '上海', 1),
(26, 1, '四川', 1),
(27, 1, '天津', 1),
(28, 1, '西藏', 1),
(29, 1, '新疆', 1),
(30, 1, '云南', 1),
(31, 1, '浙江', 1),
(32, 1, '重庆', 1),
(33, 1, '香港', 1),
(34, 1, '澳门', 1),
(35, 1, '台湾', 1),
(36, 3, '安庆', 2),
(37, 3, '蚌埠', 2),
(38, 3, '巢湖', 2),
(39, 3, '池州', 2),
(40, 3, '滁州', 2),
(41, 3, '阜阳', 2),
(42, 3, '淮北', 2),
(43, 3, '淮南', 2),
(44, 3, '黄山', 2),
(45, 3, '六安', 2),
(46, 3, '马鞍山', 2),
(47, 3, '宿州', 2),
(48, 3, '铜陵', 2),
(49, 3, '芜湖', 2),
(50, 3, '宣城', 2),
(51, 3, '亳州', 2),
(52, 2, '北京', 2),
(53, 4, '福州', 2),
(54, 4, '龙岩', 2),
(55, 4, '南平', 2),
(56, 4, '宁德', 2),
(57, 4, '莆田', 2),
(58, 4, '泉州', 2);

-- --------------------------------------------------------

--
-- 表的结构 `clt_role`
--

CREATE TABLE IF NOT EXISTS `clt_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remark` varchar(255) NOT NULL DEFAULT '',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `clt_role`
--

INSERT INTO `clt_role` (`id`, `name`, `status`, `remark`, `pid`, `sort`) VALUES
(1, '超级管理员', 1, '超级管理', 0, 0),
(2, '普通管理员', 1, '普通管理员', 0, 0),
(3, '注册用户', 1, '注册用户', 0, 0),
(4, '游客', 1, '游客', 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `clt_role_user`
--

CREATE TABLE IF NOT EXISTS `clt_role_user` (
  `role_id` mediumint(9) unsigned DEFAULT '0',
  `user_id` char(32) DEFAULT '0',
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `clt_system`
--

CREATE TABLE IF NOT EXISTS `clt_system` (
  `id` int(36) unsigned NOT NULL,
  `name` char(36) NOT NULL DEFAULT '' COMMENT '网站名称',
  `url` varchar(36) NOT NULL DEFAULT '' COMMENT '网址',
  `title` varchar(200) NOT NULL COMMENT '标题',
  `key` varchar(200) NOT NULL COMMENT '关键字',
  `des` varchar(200) NOT NULL COMMENT '描述',
  `bah` varchar(50) DEFAULT NULL COMMENT '备案号',
  `copyright` varchar(30) DEFAULT NULL COMMENT 'copyright',
  `ads` varchar(120) DEFAULT NULL COMMENT '公司地址',
  `tel` varchar(15) DEFAULT NULL COMMENT '公司电话',
  `email` varchar(50) DEFAULT NULL COMMENT '公司邮箱',
  `logo` varchar(120) DEFAULT NULL COMMENT 'logo',
  `mobile` varchar(10) DEFAULT 'open' COMMENT '是否开启手机端 open 开启 close 关闭',
  `code` varchar(10) DEFAULT 'close' COMMENT '是否开启验证码',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `clt_system`
--

INSERT INTO `clt_system` (`id`, `name`, `url`, `title`, `key`, `des`, `bah`, `copyright`, `ads`, `tel`, `email`, `logo`, `mobile`, `code`) VALUES
(1, '在线网站源码下载', 'http://cltphp.cn/', '网站模板，程序源码，php源码，视频教程，程序定制', '网站模板，程序源码，php源码，视频教程，定制开发，模块开发', '网站模板，程序源码，php源码，视频教程，微信公众平台、APP移动应用设计、HTML5网站API定制开发。大型企业网站、个人博客论坛、手机网站定制开发。更高效、更快捷的进行定制开发。', '沪ICP备12038604号-6', '2015-2019', '上海市普陀区真北路', '13122707159', '1158624818@qq.com', '/uploads/20181211/004d101f630559eb27afbcdb58d8bdf2.jpg', 'open', 'open');

-- --------------------------------------------------------

--
-- 表的结构 `clt_team`
--

CREATE TABLE IF NOT EXISTS `clt_team` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL DEFAULT '',
  `title_style` varchar(225) NOT NULL DEFAULT '',
  `thumb` varchar(225) NOT NULL DEFAULT '',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `info` text NOT NULL,
  `template` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- 表的结构 `clt_users`
--

CREATE TABLE IF NOT EXISTS `clt_users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '表id',
  `email` varchar(60) NOT NULL DEFAULT '' COMMENT '邮件',
  `password` varchar(32) NOT NULL DEFAULT '' COMMENT '密码',
  `paypwd` varchar(32) DEFAULT NULL COMMENT '支付密码',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 男 0 女',
  `birthday` int(11) NOT NULL DEFAULT '0' COMMENT '生日',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_ip` varchar(15) NOT NULL DEFAULT '' COMMENT '最后登录ip',
  `qq` varchar(20) NOT NULL DEFAULT '' COMMENT 'QQ',
  `mobile` varchar(20) NOT NULL DEFAULT '' COMMENT '手机号码',
  `mobile_validated` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否验证手机',
  `oauth` varchar(10) DEFAULT '' COMMENT '第三方来源 wx weibo alipay',
  `openid` varchar(100) DEFAULT NULL COMMENT '第三方唯一标示',
  `unionid` varchar(100) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像',
  `province` int(6) DEFAULT '0' COMMENT '省份',
  `city` int(6) DEFAULT '0' COMMENT '市区',
  `district` int(6) DEFAULT '0' COMMENT '县',
  `email_validated` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否验证电子邮箱',
  `username` varchar(50) DEFAULT NULL COMMENT '第三方返回昵称',
  `level` tinyint(1) DEFAULT '1' COMMENT '会员等级',
  `is_lock` tinyint(1) DEFAULT '0' COMMENT '是否被锁定冻结',
  `token` varchar(64) DEFAULT '' COMMENT '用于app 授权类似于session_id',
  `sign` varchar(255) DEFAULT '' COMMENT '签名',
  `status` varchar(20) DEFAULT 'hide' COMMENT '登录状态',
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `clt_users`
--

INSERT INTO `clt_users` (`id`, `email`, `password`, `paypwd`, `sex`, `birthday`, `reg_time`, `last_login`, `last_ip`, `qq`, `mobile`, `mobile_validated`, `oauth`, `openid`, `unionid`, `avatar`, `province`, `city`, `district`, `email_validated`, `username`, `level`, `is_lock`, `token`, `sign`, `status`) VALUES
(3, '', '0514d744721046aaaccbc1585b1058d1', NULL, 0, 0, 1544592076, 0, '', '', '13122707159', 1, '', NULL, NULL, '/uploads/20181212/35ffcc4acf0aba38e1ef22df340cd79a.png', 0, 0, 0, 0, 'dong', 1, 0, '', '', 'hide');

-- --------------------------------------------------------

--
-- 表的结构 `clt_user_level`
--

CREATE TABLE IF NOT EXISTS `clt_user_level` (
  `level_id` smallint(4) unsigned NOT NULL AUTO_INCREMENT COMMENT '表id',
  `level_name` varchar(30) DEFAULT NULL COMMENT '头衔名称',
  `sort` int(3) DEFAULT '0' COMMENT '排序',
  `bomlimit` int(5) DEFAULT '0' COMMENT '积分下限',
  `toplimit` int(5) DEFAULT '0' COMMENT '积分上限',
  PRIMARY KEY (`level_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- 转存表中的数据 `clt_user_level`
--

INSERT INTO `clt_user_level` (`level_id`, `level_name`, `sort`, `bomlimit`, `toplimit`) VALUES
(1, '注册会员', 1, 0, 500),
(2, '铜牌会员', 2, 501, 1000),
(3, '白银会员', 3, 1001, 2000),
(4, '黄金会员', 4, 2001, 3500),
(5, '钻石会员', 5, 3501, 5500),
(6, '超级VIP', 6, 5500, 99999);

-- --------------------------------------------------------

--
-- 表的结构 `clt_wx_auth`
--

CREATE TABLE IF NOT EXISTS `clt_wx_auth` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `instance_id` int(11) NOT NULL DEFAULT '0' COMMENT '店铺id',
  `authorizer_appid` varchar(255) NOT NULL DEFAULT '' COMMENT '店铺的appid  授权之后不用刷新',
  `authorizer_refresh_token` varchar(255) NOT NULL DEFAULT '' COMMENT '店铺授权之后的刷新token，每月刷新',
  `authorizer_access_token` varchar(255) NOT NULL DEFAULT '' COMMENT '店铺的公众号token，只有2小时',
  `func_info` varchar(1000) NOT NULL DEFAULT '' COMMENT '授权项目',
  `nick_name` varchar(50) NOT NULL DEFAULT '' COMMENT '公众号昵称',
  `head_img` varchar(255) NOT NULL DEFAULT '' COMMENT '公众号头像url',
  `user_name` varchar(50) NOT NULL DEFAULT '' COMMENT '公众号原始账号',
  `alias` varchar(255) NOT NULL DEFAULT '' COMMENT '公众号原始名称',
  `qrcode_url` varchar(255) NOT NULL DEFAULT '' COMMENT '公众号二维码url',
  `auth_time` int(11) DEFAULT '0' COMMENT '授权时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=8192 COMMENT='店铺(实例)微信公众账号授权' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `clt_wx_config`
--

CREATE TABLE IF NOT EXISTS `clt_wx_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `instance_id` int(11) NOT NULL DEFAULT '1' COMMENT '实例ID',
  `key` varchar(255) NOT NULL DEFAULT '' COMMENT '配置项WCHAT,QQ,WPAY,ALIPAY...',
  `value` varchar(1000) NOT NULL DEFAULT '' COMMENT '配置值json',
  `desc` varchar(1000) NOT NULL DEFAULT '' COMMENT '描述',
  `is_use` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否启用 1启用 0不启用',
  `create_time` int(11) DEFAULT '0' COMMENT '创建时间',
  `modify_time` int(11) DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=963 COMMENT='第三方配置表' AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `clt_wx_config`
--

INSERT INTO `clt_wx_config` (`id`, `instance_id`, `key`, `value`, `desc`, `is_use`, `create_time`, `modify_time`) VALUES
(1, 0, 'WCHAT', '{"APP_KEY":"","APP_SECRET":"","AUTHORIZE":"http:\\/\\/b2c1.01.niushop.com.cn","CALLBACK":"http:\\/\\/b2c1.01.niushop.com.cn\\/wap\\/Login\\/callback"}', '微信', 0, 1488350947, 1497105440),
(2, 0, 'SHOPWCHAT', '{"appid":"dfdsfdsf90bc7b7a","appsecret":"e5147ce07128asdfds222f628b5c3fe1af2ea5797","token":"dffdf"}', '', 1, 1497088090, 1528690160);

-- --------------------------------------------------------

--
-- 表的结构 `clt_wx_default_replay`
--

CREATE TABLE IF NOT EXISTS `clt_wx_default_replay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `instance_id` int(11) NOT NULL COMMENT '店铺id',
  `reply_media_id` int(11) NOT NULL COMMENT '回复媒体内容id',
  `sort` int(11) NOT NULL,
  `create_time` int(11) DEFAULT '0',
  `modify_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=16384 COMMENT='关注时回复' AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `clt_wx_default_replay`
--

INSERT INTO `clt_wx_default_replay` (`id`, `instance_id`, `reply_media_id`, `sort`, `create_time`, `modify_time`) VALUES
(3, 0, 4, 0, 1528695059, 0);

-- --------------------------------------------------------

--
-- 表的结构 `clt_wx_fans`
--

CREATE TABLE IF NOT EXISTS `clt_wx_fans` (
  `fans_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '粉丝ID',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '会员编号ID',
  `source_uid` int(11) NOT NULL DEFAULT '0' COMMENT '推广人uid',
  `instance_id` int(11) NOT NULL COMMENT '店铺ID',
  `nickname` varchar(255) NOT NULL COMMENT '昵称',
  `nickname_decode` varchar(255) DEFAULT '',
  `headimgurl` varchar(500) NOT NULL DEFAULT '' COMMENT '头像',
  `sex` smallint(6) NOT NULL DEFAULT '1' COMMENT '性别',
  `language` varchar(20) NOT NULL DEFAULT '' COMMENT '用户语言',
  `country` varchar(60) NOT NULL DEFAULT '' COMMENT '国家',
  `province` varchar(255) NOT NULL DEFAULT '' COMMENT '省',
  `city` varchar(255) NOT NULL DEFAULT '' COMMENT '城市',
  `district` varchar(255) NOT NULL DEFAULT '' COMMENT '行政区/县',
  `openid` varchar(255) NOT NULL DEFAULT '' COMMENT '用户的标识，对当前公众号唯一     用户的唯一身份ID',
  `unionid` varchar(255) NOT NULL DEFAULT '' COMMENT '粉丝unionid',
  `groupid` int(11) NOT NULL DEFAULT '0' COMMENT '粉丝所在组id',
  `is_subscribe` bigint(1) NOT NULL DEFAULT '1' COMMENT '是否订阅',
  `memo` varchar(255) NOT NULL COMMENT '备注',
  `subscribe_date` int(11) DEFAULT '0' COMMENT '订阅时间',
  `unsubscribe_date` int(11) DEFAULT '0' COMMENT '解订阅时间',
  `update_date` int(11) DEFAULT '0' COMMENT '粉丝信息最后更新时间',
  PRIMARY KEY (`fans_id`),
  KEY `IDX_sys_weixin_fans_openid` (`openid`),
  KEY `IDX_sys_weixin_fans_unionid` (`unionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=1638 COMMENT='微信公众号获取粉丝列表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `clt_wx_follow_replay`
--

CREATE TABLE IF NOT EXISTS `clt_wx_follow_replay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `instance_id` int(11) NOT NULL COMMENT '店铺id',
  `reply_media_id` int(11) NOT NULL COMMENT '回复媒体内容id',
  `sort` int(11) NOT NULL,
  `create_time` int(11) DEFAULT '0',
  `modify_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=16384 COMMENT='关注时回复' AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `clt_wx_follow_replay`
--

INSERT INTO `clt_wx_follow_replay` (`id`, `instance_id`, `reply_media_id`, `sort`, `create_time`, `modify_time`) VALUES
(2, 0, 1, 0, 1528695047, 0);

-- --------------------------------------------------------

--
-- 表的结构 `clt_wx_key_replay`
--

CREATE TABLE IF NOT EXISTS `clt_wx_key_replay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `instance_id` int(11) NOT NULL COMMENT '店铺id',
  `key` varchar(255) NOT NULL COMMENT '关键词',
  `match_type` tinyint(4) NOT NULL COMMENT '匹配类型1模糊匹配2全部匹配',
  `reply_media_id` int(11) NOT NULL COMMENT '回复媒体内容id',
  `sort` int(11) NOT NULL,
  `create_time` int(11) DEFAULT '0',
  `modify_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=16384 COMMENT='关键词回复' AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `clt_wx_key_replay`
--

INSERT INTO `clt_wx_key_replay` (`id`, `instance_id`, `key`, `match_type`, `reply_media_id`, `sort`, `create_time`, `modify_time`) VALUES
(2, 0, '你好', 1, 3, 0, 1528696514, 0);

-- --------------------------------------------------------

--
-- 表的结构 `clt_wx_media`
--

CREATE TABLE IF NOT EXISTS `clt_wx_media` (
  `media_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '图文消息id',
  `title` varchar(100) DEFAULT NULL,
  `instance_id` int(11) NOT NULL DEFAULT '0' COMMENT '实例id店铺id',
  `type` varchar(255) NOT NULL DEFAULT '1' COMMENT '类型1文本(项表无内容) 2单图文 3多图文',
  `sort` int(11) NOT NULL DEFAULT '0',
  `create_time` int(11) DEFAULT '0' COMMENT '创建日期',
  `modify_time` int(11) DEFAULT '0' COMMENT '修改日期',
  PRIMARY KEY (`media_id`),
  UNIQUE KEY `id` (`media_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=1170 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `clt_wx_media`
--

INSERT INTO `clt_wx_media` (`media_id`, `title`, `instance_id`, `type`, `sort`, `create_time`, `modify_time`) VALUES
(1, '欢迎您来到CLTPHP官方公众号大世界！', 0, '1', 0, 1512551413, 0),
(2, '你好，欢迎来到CLTPHP的世界！', 0, '1', 0, 1512550726, 0),
(3, 'CLTPHP内容管理系统', 0, '2', 0, 1512550547, 0),
(4, 'CLTPHP内容管理系统5.2.2发布', 0, '3', 0, 1528694363, 0),
(5, 'CLTPHP操作开发手册已完全更新', 0, '2', 0, 1528694392, 0),
(6, '1111', 0, '1', 0, 1528694379, 0);

-- --------------------------------------------------------

--
-- 表的结构 `clt_wx_media_item`
--

CREATE TABLE IF NOT EXISTS `clt_wx_media_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `media_id` int(11) NOT NULL COMMENT '图文消息id',
  `title` varchar(100) DEFAULT NULL,
  `author` varchar(50) NOT NULL COMMENT '作者',
  `cover` varchar(200) NOT NULL COMMENT '图文消息封面',
  `show_cover_pic` tinyint(4) NOT NULL DEFAULT '1' COMMENT '封面图片显示在正文中',
  `summary` text,
  `content` text NOT NULL COMMENT '正文',
  `content_source_url` varchar(200) NOT NULL DEFAULT '' COMMENT '图文消息的原文地址，即点击“阅读原文”后的URL',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序号',
  `hits` int(11) NOT NULL DEFAULT '0' COMMENT '阅读次数',
  PRIMARY KEY (`id`),
  KEY `id` (`media_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=712 AUTO_INCREMENT=52 ;

--
-- 转存表中的数据 `clt_wx_media_item`
--

INSERT INTO `clt_wx_media_item` (`id`, `media_id`, `title`, `author`, `cover`, `show_cover_pic`, `summary`, `content`, `content_source_url`, `sort`, `hits`) VALUES
(28, 3, 'CLTPHP内容管理系统', 'cltphp', '/uploads/20171206/6dfec00133ee42c5c33cea8ab0cfad8f.png', 1, 'CLTPHP内容管理系统，微信公众平台、APP移动应用设计、HTML5网站API定制开发。大型企业网站、个人博客论坛、手机网站定制开发。更高效、更快捷的进行定制开发。', '<p style="text-indent: 2em;"><span style="text-indent: 2em;">虽然世界上有成千上万的建站系统，但CLTPHP会告诉你，真正高效的建站系统是什么样的。</span><br/></p><p style="text-indent: 2em;"><br/></p><p style="text-indent: 2em;">CLTPHP采用了优美的layui框架，一面极简，一面丰盈。加上angular Js，让数据交互变得更为简洁直白。用最基础的代码，实现最强大的效果，让你欲罢不能！</p><p style="text-indent: 2em;"><br/></p><p style="text-indent: 2em;">CLTPHP采用的ThinkPHP5为基础框架，从而使得CLTPHP的拓展性变的极为强大。从模型构造到栏目建立，再到前台展示，一气呵成，网站后台一条龙式操作，让小白用户能快速掌握CLTPHP管理系统的核心操作，让小白开发者能更好的理解CLTPHP的核心构建价值。</p><p><br/></p>', 'http://www.cltphp.com/', 0, 6),
(29, 2, '你好，欢迎来到CLTPHP的世界！', '', '', 0, '', '', '', 0, 0),
(42, 1, '欢迎您来到CLTPHP官方公众号大世界！', '', '', 0, '', '', '', 0, 0),
(47, 4, 'CLTPHP内容管理系统5.2.2发布', 'chichu', '/uploads/20180611/5df2c8dabd33e0a0672dcb94b51d5ada.jpg', 1, '这是一篇多图文', '<h4 style="box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-weight: normal; font-stretch: inherit; font-size: 22px; line-height: inherit; font-family: ">CLTPHP5.2.2发布</h4><p style="box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: "><span style="box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; vertical-align: baseline; margin: 0px; padding: 0px;">修改bug若干</span></p><p style="box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: "><span style="box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px;">下载地址：</span><span style="box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; margin: 0px; padding: 0px;"><span style="box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px;"><a href="http://qiniu.cltphp.com/cltphp5.2.2.zip" target="_self" title="CLTPHP5.2.2" style="box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; margin: 0px; padding: 0px; color: rgb(0, 176, 80); outline: 0px;"><span style="box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px; text-decoration: none;">CLTPHP5.2.2</span></a></span></span></p><p style="box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px;"><span style="box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px;">补丁地址：</span><span style="box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px;"><span style="box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; margin: 0px; padding: 0px; color: rgb(0, 176, 80); outline: 0px;"><span style="box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px; text-decoration: none;"><a href="http://qiniu.cltphp.com/CLTPHP5.2.1%E5%88%B05.2.2%E8%A1%A5%E4%B8%81.zip" target="_self" style="box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; margin: 0px; padding: 0px; color: rgb(0, 176, 80); outline: 0px;">CLTPHP5.2.1到5.2.2升级</a></span></span></span></p>', 'http://www.cltphp.com/newsInfo-44-5.html', 0, 0),
(48, 4, '给我们一点点时间 我们给你一个新突破', 'chichu', '/uploads/20171206/18fd882e982e07e7b35dac5b962ab393.jpg', 0, '给我们一点点时间 我们给你一个新突破', '<p><span style="color: rgb(102, 102, 102); font-family: ">说实话，最近这段时间我们太忙了</span><img src="http://img.baidu.com/hi/jx2/j_0016.gif"/><span style="color: rgb(102, 102, 102); font-family: ">，cltphp的开发，甚至可以说是搁浅了一段时间。不过，各位请耐心等待一下啊，给我们一点点时间，或许不止一点点，我们给你一个新突破。</span></p>', 'http://www.cltphp.com/newsInfo-45-5.html', 0, 0),
(49, 4, 'CLTPHP操作开发手册已完全更新', 'chichu', '/uploads/20171206/db19ac0c46a3ffd4ebf94028024d3036.jpg', 1, 'CLTPHP操作开发手册已完全更新，CLTPHP核心价值，尽在其中。', '<p style="box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: ">CLTPHP操作开发手册已完全更新，CLTPHP核心价值，尽在其中。</p><p style="box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: ">喜欢的朋友可以购买参考</p><p style="box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: ">同时希望CLTPHP的爱好者，可以给我提出更多CLTPHP的不足之处，让CLTPHP更健康的成长。</p><p style="box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: ">手册地址：<a href="https://www.kancloud.cn/chichu/cltphp/" target="_self">https://www.kancloud.cn/chichu/cltphp/</a></p><p><br/></p>', 'http://www.cltphp.com/newsInfo-16-5.html', 0, 0),
(50, 6, '1111', '', '', 0, '', '', '', 0, 0),
(51, 5, 'CLTPHP操作开发手册已完全更新', 'chichu', '/uploads/20180611/12e57c01f2bd9172c8c26de45cb796a6.jpg', 0, 'CLTPHP操作开发手册已完全更新，CLTPHP核心价值，尽在其中。', '<p style="box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; text-indent: 2em;">CLTPHP操作开发手册已完全更新，CLTPHP核心价值，尽在其中。</p><p style="box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: ">喜欢的朋友可以购买参考</p><p style="box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; text-indent: 2em;">同时希望CLTPHP的爱好者，可以给我提出更多CLTPHP的不足之处，让CLTPHP更健康的成长。</p><p style="box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; text-indent: 2em;">手册地址：https://www.kancloud.cn/chichu/cltphp/</p><p><br/></p>', 'https://www.kancloud.cn/chichu/cltphp', 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `clt_wx_menu`
--

CREATE TABLE IF NOT EXISTS `clt_wx_menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `instance_id` int(11) NOT NULL DEFAULT '0' COMMENT '店铺id',
  `menu_name` varchar(50) NOT NULL DEFAULT '' COMMENT '菜单名称',
  `ico` varchar(32) NOT NULL DEFAULT '' COMMENT '菜图标单',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父菜单',
  `menu_event_type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1普通url 2 图文素材 3 功能',
  `media_id` int(11) NOT NULL DEFAULT '0' COMMENT '图文消息ID',
  `menu_event_url` varchar(255) NOT NULL DEFAULT '' COMMENT '菜单url',
  `hits` int(11) NOT NULL DEFAULT '0' COMMENT '触发数',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_date` int(11) DEFAULT '0' COMMENT '创建日期',
  `modify_date` int(11) DEFAULT '0' COMMENT '修改日期',
  PRIMARY KEY (`menu_id`),
  KEY `IDX_biz_shop_menu_orders` (`sort`),
  KEY `IDX_biz_shop_menu_shopId` (`instance_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=1638 COMMENT='微设置->微店菜单' AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `clt_wx_menu`
--

INSERT INTO `clt_wx_menu` (`menu_id`, `instance_id`, `menu_name`, `ico`, `pid`, `menu_event_type`, `media_id`, `menu_event_url`, `hits`, `sort`, `create_date`, `modify_date`) VALUES
(1, 0, '官网', '', 0, 2, 0, 'http://www.cltphp.com/', 0, 1, 1512442512, 0),
(2, 0, '手册', '', 0, 2, 5, 'http://www.cltphp.com/', 0, 2, 1512442543, 0),
(3, 0, '论坛', '', 0, 2, 4, 'http://bbs.cltphp.com/', 0, 3, 1512547727, 0),
(4, 0, '百度', '', 3, 1, 0, 'http://www.baodu.com', 0, 1, 1542783759, 0),
(5, 0, '子菜单名称', '', 1, 1, 0, '', 0, 1, 1544591336, 0),
(6, 0, '子菜单名称', '', 1, 1, 0, '', 0, 2, 1544591339, 0),
(7, 0, '子菜单名称', '', 1, 1, 0, '', 0, 3, 1544591340, 0);

-- --------------------------------------------------------

--
-- 表的结构 `clt_wx_user`
--

CREATE TABLE IF NOT EXISTS `clt_wx_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '表id',
  `uid` int(11) NOT NULL COMMENT 'uid',
  `wxname` varchar(60) NOT NULL COMMENT '公众号名称',
  `aeskey` varchar(256) NOT NULL DEFAULT '' COMMENT 'aeskey',
  `encode` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'encode',
  `appid` varchar(50) NOT NULL DEFAULT '' COMMENT 'appid',
  `appsecret` varchar(50) NOT NULL DEFAULT '' COMMENT 'appsecret',
  `wxid` varchar(64) NOT NULL COMMENT '公众号原始ID',
  `weixin` char(64) NOT NULL COMMENT '微信号',
  `token` char(255) NOT NULL COMMENT 'token',
  `w_token` varchar(150) NOT NULL DEFAULT '' COMMENT '微信对接token',
  `create_time` int(11) NOT NULL COMMENT 'create_time',
  `updatetime` int(11) NOT NULL COMMENT 'updatetime',
  `tplcontentid` varchar(2) NOT NULL COMMENT '内容模版ID',
  `share_ticket` varchar(150) NOT NULL COMMENT '分享ticket',
  `share_dated` char(15) NOT NULL COMMENT 'share_dated',
  `authorizer_access_token` varchar(200) NOT NULL COMMENT 'authorizer_access_token',
  `authorizer_refresh_token` varchar(200) NOT NULL COMMENT 'authorizer_refresh_token',
  `authorizer_expires` char(10) NOT NULL COMMENT 'authorizer_expires',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型',
  `web_access_token` varchar(200) NOT NULL COMMENT '网页授权token',
  `web_refresh_token` varchar(200) NOT NULL COMMENT 'web_refresh_token',
  `web_expires` int(11) NOT NULL COMMENT '过期时间',
  `menu_config` text COMMENT '菜单',
  `wait_access` tinyint(1) DEFAULT '0' COMMENT '微信接入状态,0待接入1已接入',
  `concern` varchar(225) DEFAULT '' COMMENT '关注回复',
  `default` varchar(225) DEFAULT '' COMMENT '默认回复',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `uid_2` (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='微信公共帐号' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `clt_wx_user`
--

INSERT INTO `clt_wx_user` (`id`, `uid`, `wxname`, `aeskey`, `encode`, `appid`, `appsecret`, `wxid`, `weixin`, `token`, `w_token`, `create_time`, `updatetime`, `tplcontentid`, `share_ticket`, `share_dated`, `authorizer_access_token`, `authorizer_refresh_token`, `authorizer_expires`, `type`, `web_access_token`, `web_refresh_token`, `web_expires`, `menu_config`, `wait_access`, `concern`, `default`) VALUES
(1, 0, 'CLTPHP', '', 0, 'wx08c8be078e00b88b', '2e6f2d97d60582f21111be7862d14ddc', 'gh_8aacbef4e497', 'chichu12345', 'sdfdsfdsfdsf', 'cltphp', 0, 0, '', '', '', '', '', '', 1, 'eY9W4LLdISpE3UtTfuodgz1HJdBYCMbzZWkiLEhF0Nzvzv2q2DtGIV5h7CPrc0Nd4_kJgKN_FdM3kNaCxfFC1wmu6JLnNoOrmMuy3FK2AhMDLCbAGAXFW', '', 1504242136, '0', 0, '欢迎来到CLTPHP！CLTPHP采用ThinkPHP5作为基础框架，同时采用Layui作为后台界面，使得CLTPHP适用与大型企业网站、个人博客论坛、企业网站、手机网站的定制开发。更高效、更快捷的进行定制开发一直是CLTPHP追求的价值。', '亲！您可以输入关键词来获取您想要知道的内容。（例：手册）');

-- --------------------------------------------------------

--
-- 表的结构 `clt_wx_user_msg`
--

CREATE TABLE IF NOT EXISTS `clt_wx_user_msg` (
  `msg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `msg_type` varchar(255) NOT NULL,
  `content` text,
  `is_replay` int(11) NOT NULL DEFAULT '0' COMMENT '是否回复',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='微信用户消息表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `clt_wx_user_msg_replay`
--

CREATE TABLE IF NOT EXISTS `clt_wx_user_msg_replay` (
  `replay_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msg_id` int(11) NOT NULL,
  `replay_uid` int(11) NOT NULL COMMENT '当前客服uid',
  `replay_type` varchar(255) NOT NULL,
  `content` text,
  `replay_time` int(11) DEFAULT '0',
  PRIMARY KEY (`replay_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='微信用户消息回复表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `posts_tags`
--

CREATE TABLE IF NOT EXISTS `posts_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) DEFAULT NULL,
  `posts_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT '' COMMENT '标签名称',
  `nums` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
